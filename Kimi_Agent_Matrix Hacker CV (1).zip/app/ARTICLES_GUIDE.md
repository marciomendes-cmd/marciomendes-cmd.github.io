# 📄 Articles Configuration Guide

## Como Adicionar/Editar/Remover Artigos

Todos os artigos são gerenciados no arquivo:
```
src/config/articles.ts
```

---

## 📝 Estrutura de um Artigo

```typescript
{
  id: 'unique-identifier',           // ID único (sem espaços)
  title: 'Article Title',            // Título do artigo
  type: 'peerspot' | 'casestudy' | 'bugbounty' | 'writeup',
  excerpt: 'Short description...',   // Resumo curto (1-2 linhas)
  content: [                         // Array de parágrafos
    'First paragraph...',
    'Second paragraph...',
    'Third paragraph...',
  ],
  link?: 'https://...',              // Link externo (opcional)
  date: '2024',                      // Ano de publicação
  tags: ['Tag1', 'Tag2', 'Tag3'],    // Tags para filtragem
  featured: true | false,            // Destacar na seção principal?
}
```

---

## 🎯 Tipos de Artigos

| Tipo | Cor | Uso |
|------|-----|-----|
| `peerspot` | Verde (#00ff41) | Reviews no PeerSpot |
| `casestudy` | Ciano (#00ffff) | Case studies técnicos |
| `bugbounty` | Roxo (#ff00ff) | Relatórios de bug bounty |
| `writeup` | Amarelo (#ffff00) | Artigos técnicos gerais |

---

## ➕ Adicionar um Novo Artigo

1. Abra o arquivo `src/config/articles.ts`
2. Adicione um novo objeto no array `articles`
3. Siga a estrutura acima

### Exemplo:

```typescript
{
  id: 'meu-novo-artigo',
  title: 'Meu Novo Artigo Técnico',
  type: 'writeup',
  excerpt: 'Um resumo do que o artigo aborda...',
  content: [
    'Primeiro parágrafo introduzindo o tema.',
    'Segundo parágrafo com detalhes técnicos.',
    'Terceiro parágrafo com conclusões.',
  ],
  link: 'https://meublog.com/artigo',  // opcional
  date: '2024',
  tags: ['Cybersecurity', 'Vulnerability', 'Qualys'],
  featured: false,
}
```

---

## ✏️ Editar um Artigo Existente

1. Localize o artigo pelo `id` no array
2. Modifique os campos desejados
3. Salve o arquivo

---

## 🗑️ Remover um Artigo

1. Localize o artigo pelo `id`
2. Delete todo o objeto (incluindo as chaves `{}`)
3. **Não esqueça da vírgula!** Se remover o último artigo, remova a vírgula do anterior.

---

## 🌟 Destacar um Artigo

Artigos com `featured: true` aparecem na seção "FEATURED PUBLICATIONS" no topo da página.

Máximo recomendado: **2 artigos destacados**

---

## 🏷️ Tags

Tags são usadas para filtragem. Algumas sugestões:
- `Qualys`
- `Tenable`
- `Vulnerability Management`
- `Risk Assessment`
- `MITRE ATT&CK`
- `Cloud Security`
- `AWS`
- `API Security`
- `Bug Bounty`

---

## 🚀 Depois de Editar

Após fazer alterações, você precisa fazer o **build** novamente:

```bash
cd /mnt/okcomputer/output/app
npm run build
```

Os arquivos atualizados estarão na pasta `dist/`.

---

## 📋 Artigos Atuais

1. **PeerSpot Review 1** - Asset Intelligence (Qualys CSAM)
2. **PeerSpot Review 2** - Patch Management (Qualys)
3. **Case Study** - How I Prioritize Beyond CVSS
4. **Bug Bounty** - API Authorization Bypass Report
5. **Write-up** - Reducing MTTR with Automation

---

## 💡 Dicas

- Use IDs descritivos e únicos (ex: `casestudy-beyond-cvss`)
- Mantenha o `excerpt` curto (máximo 2 linhas)
- O `content` pode ter quantos parágrafos quiser
- Use `featured: true` apenas para seus melhores artigos
- Adicione tags relevantes para facilitar a descoberta
