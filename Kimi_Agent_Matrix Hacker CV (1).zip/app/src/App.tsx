import MatrixRain from './components/MatrixRain';
import FloatingCode from './components/FloatingCode';
import ScanLine from './components/ScanLine';
import Navigation from './components/Navigation';
import HeroSection from './sections/HeroSection';
import SkillsSection from './sections/SkillsSection';
import ExperienceSection from './sections/ExperienceSection';
import CertificationsSection from './sections/CertificationsSection';
import EducationSection from './sections/EducationSection';
import ArticlesSection from './sections/ArticlesSection';
import ContactSection from './sections/ContactSection';
import FooterSection from './sections/FooterSection';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-[#0d0208] text-[#00ff41] relative overflow-x-hidden">
      {/* Background Effects */}
      <MatrixRain />
      <FloatingCode />
      <ScanLine />
      
      {/* Scanlines Overlay */}
      <div className="scanlines"></div>
      
      {/* CRT Flicker Effect */}
      <div className="crt-flicker fixed inset-0 pointer-events-none z-[999]"></div>
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main Content */}
      <main className="relative z-10">
        <HeroSection />
        
        <div id="skills">
          <SkillsSection />
        </div>
        
        <div id="experience">
          <ExperienceSection />
        </div>
        
        <div id="certifications">
          <CertificationsSection />
        </div>
        
        <div id="education">
          <EducationSection />
        </div>
        
        <div id="articles">
          <ArticlesSection />
        </div>
        
        <div id="contact">
          <ContactSection />
        </div>
        
        <FooterSection />
      </main>
      
      {/* Grid Background Overlay */}
      <div className="fixed inset-0 pointer-events-none z-[1] grid-bg opacity-30"></div>
    </div>
  );
}

export default App;
