import { useEffect, useState } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  char: string;
  opacity: number;
  speed: number;
}

const FloatingCode = () => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const chars = '01';
    const initialParticles: Particle[] = [];
    
    for (let i = 0; i < 30; i++) {
      initialParticles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        char: chars[Math.floor(Math.random() * chars.length)],
        opacity: Math.random() * 0.3 + 0.1,
        speed: Math.random() * 0.5 + 0.2,
      });
    }
    
    setParticles(initialParticles);

    const interval = setInterval(() => {
      setParticles(prev => 
        prev.map(p => ({
          ...p,
          y: p.y - p.speed,
          opacity: p.y < 10 ? p.opacity - 0.01 : p.opacity,
          ...(p.y < 0 || p.opacity <= 0 ? {
            y: 100,
            x: Math.random() * 100,
            opacity: Math.random() * 0.3 + 0.1,
            char: chars[Math.floor(Math.random() * chars.length)],
          } : {})
        }))
      );
    }, 50);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map(p => (
        <span
          key={p.id}
          className="absolute font-mono text-sm"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            opacity: p.opacity,
            color: '#00ff41',
            textShadow: '0 0 5px rgba(0, 255, 65, 0.5)',
          }}
        >
          {p.char}
        </span>
      ))}
    </div>
  );
};

export default FloatingCode;
