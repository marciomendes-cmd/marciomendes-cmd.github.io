import type { ReactNode } from 'react';

interface TerminalWindowProps {
  title?: string;
  children: ReactNode;
  className?: string;
  showDots?: boolean;
}

const TerminalWindow = ({ 
  title = 'terminal@cyber-neural:~', 
  children, 
  className = '',
  showDots = true 
}: TerminalWindowProps) => {
  return (
    <div className={`terminal-window ${className}`}>
      <div className="terminal-header">
        {showDots && (
          <>
            <div className="terminal-dot red"></div>
            <div className="terminal-dot yellow"></div>
            <div className="terminal-dot green"></div>
          </>
        )}
        <span className="ml-4 text-xs text-[#00ff41]/70 font-mono">{title}</span>
      </div>
      <div className="p-4 font-mono text-sm">
        {children}
      </div>
    </div>
  );
};

export default TerminalWindow;
