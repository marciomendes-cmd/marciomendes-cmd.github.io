import { useEffect, useState } from 'react';

const ScanLine = () => {
  const [position, setPosition] = useState(-100);

  useEffect(() => {
    const animate = () => {
      setPosition(prev => {
        if (prev > window.innerHeight + 100) {
          return -100;
        }
        return prev + 2;
      });
    };

    const interval = setInterval(animate, 16);
    return () => clearInterval(interval);
  }, []);

  return (
    <div 
      className="fixed left-0 w-full h-1 pointer-events-none z-50"
      style={{ 
        top: `${position}px`,
        background: 'linear-gradient(180deg, transparent, rgba(0, 255, 65, 0.5), transparent)',
        boxShadow: '0 0 20px rgba(0, 255, 65, 0.5)',
      }}
    />
  );
};

export default ScanLine;
