import { useEffect, useRef } from 'react';

const MatrixRain = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Matrix characters - mix of katakana, latin, numbers
    const chars = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charArray = chars.split('');

    // Column setup
    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize);
    
    // Drops array - each column has a drop
    const drops: number[] = [];
    for (let i = 0; i < columns; i++) {
      drops[i] = Math.random() * -100; // Start at random heights above screen
    }

    // Colors
    const matrixGreen = '#00ff41';
    const matrixDark = '#003b00';
    const matrixBright = '#00ff00';

    let animationId: number;
    let frameCount = 0;

    const draw = () => {
      frameCount++;
      
      // Only draw every 2nd frame for performance
      if (frameCount % 2 !== 0) {
        animationId = requestAnimationFrame(draw);
        return;
      }

      // Semi-transparent black for trail effect
      ctx.fillStyle = 'rgba(13, 2, 8, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = `${fontSize}px 'Courier New', monospace`;

      for (let i = 0; i < drops.length; i++) {
        // Random character
        const char = charArray[Math.floor(Math.random() * charArray.length)];
        
        // x position
        const x = i * fontSize;
        // y position
        const y = drops[i] * fontSize;

        // Randomly make some characters brighter (leading characters)
        if (Math.random() > 0.975) {
          ctx.fillStyle = matrixBright;
          ctx.shadowColor = matrixBright;
          ctx.shadowBlur = 10;
        } else if (Math.random() > 0.9) {
          ctx.fillStyle = matrixGreen;
          ctx.shadowColor = matrixGreen;
          ctx.shadowBlur = 5;
        } else {
          ctx.fillStyle = matrixDark;
          ctx.shadowBlur = 0;
        }

        ctx.fillText(char, x, y);
        ctx.shadowBlur = 0;

        // Reset drop when it reaches bottom or randomly
        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        // Move drop down
        drops[i]++;
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="matrix-canvas"
      className="fixed top-0 left-0 w-full h-full -z-10"
      style={{ opacity: 0.4 }}
    />
  );
};

export default MatrixRain;
