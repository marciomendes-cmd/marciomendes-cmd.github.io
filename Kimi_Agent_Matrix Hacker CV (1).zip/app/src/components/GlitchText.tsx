import { useState, useEffect } from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
  glitchInterval?: number;
}

const GlitchText = ({ 
  text, 
  className = '', 
  glitchInterval = 3000 
}: GlitchTextProps) => {
  const [isGlitching, setIsGlitching] = useState(false);
  const [glitchText, setGlitchText] = useState(text);

  const glitchChars = '▓▒░█▄▀■□▪▫▬►◄▲▼◊○●◘◙◦0123456789';

  useEffect(() => {
    const interval = setInterval(() => {
      setIsGlitching(true);
      
      // Generate glitched text
      let iterations = 0;
      const maxIterations = 5;
      
      const glitchIntervalId = setInterval(() => {
        setGlitchText(
          text
            .split('')
            .map((char) => {
              if (char === ' ') return ' ';
              if (Math.random() > 0.7) {
                return glitchChars[Math.floor(Math.random() * glitchChars.length)];
              }
              return char;
            })
            .join('')
        );
        
        iterations++;
        if (iterations >= maxIterations) {
          clearInterval(glitchIntervalId);
          setGlitchText(text);
          setIsGlitching(false);
        }
      }, 50);

    }, glitchInterval);

    return () => clearInterval(interval);
  }, [text, glitchInterval]);

  return (
    <span 
      className={`relative inline-block ${className}`}
      data-text={glitchText}
    >
      <span className={isGlitching ? 'opacity-0' : 'opacity-100'}>
        {glitchText}
      </span>
      {isGlitching && (
        <>
          <span 
            className="absolute top-0 left-0 text-[#ff00ff] z-[-1]"
            style={{ 
              clipPath: 'inset(20% 0 60% 0)',
              transform: 'translate(-2px, 2px)'
            }}
          >
            {glitchText}
          </span>
          <span 
            className="absolute top-0 left-0 text-[#00ffff] z-[-2]"
            style={{ 
              clipPath: 'inset(60% 0 20% 0)',
              transform: 'translate(2px, -2px)'
            }}
          >
            {glitchText}
          </span>
        </>
      )}
    </span>
  );
};

export default GlitchText;
