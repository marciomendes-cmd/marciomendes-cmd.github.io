import { type ReactNode, useState } from 'react';

interface HolographicCardProps {
  title: string;
  children: ReactNode;
  icon?: string;
  className?: string;
  glowColor?: 'green' | 'cyan' | 'purple' | 'yellow';
}

const HolographicCard = ({ 
  title, 
  children, 
  icon = '◈',
  className = '',
  glowColor = 'green'
}: HolographicCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  const glowColors = {
    green: 'hover:shadow-[0_0_30px_rgba(0,255,65,0.4)] hover:border-[#00ff41]',
    cyan: 'hover:shadow-[0_0_30px_rgba(0,255,255,0.4)] hover:border-[#00ffff]',
    purple: 'hover:shadow-[0_0_30px_rgba(255,0,255,0.4)] hover:border-[#ff00ff]',
    yellow: 'hover:shadow-[0_0_30px_rgba(255,255,0,0.4)] hover:border-[#ffff00]',
  };

  const iconColors = {
    green: 'text-[#00ff41]',
    cyan: 'text-[#00ffff]',
    purple: 'text-[#ff00ff]',
    yellow: 'text-[#ffff00]',
  };

  return (
    <div 
      className={`holo-card p-6 rounded-lg transition-all duration-300 ${glowColors[glowColor]} ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center gap-3 mb-4">
        <span className={`text-2xl ${iconColors[glowColor]} ${isHovered ? 'animate-pulse' : ''}`}>
          {icon}
        </span>
        <h3 className="text-lg font-bold text-[#00ff41] font-mono uppercase tracking-wider">
          {title}
        </h3>
      </div>
      <div className="text-[#00ff41]/80 text-sm leading-relaxed">
        {children}
      </div>
      <div className="mt-4 pt-4 border-t border-[#00ff41]/20">
        <div className="flex items-center gap-2 text-xs text-[#00ff41]/50 font-mono">
          <span className="animate-pulse">●</span>
          <span>SYSTEM_ACTIVE</span>
          <span className="ml-auto">[OK]</span>
        </div>
      </div>
    </div>
  );
};

export default HolographicCard;
