import { useState, useEffect } from 'react';

interface MatrixProgressProps {
  label: string;
  targetValue: number;
  duration?: number;
  className?: string;
}

const MatrixProgress = ({ 
  label, 
  targetValue, 
  duration = 2000,
  className = '' 
}: MatrixProgressProps) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setValue(Math.floor(easeOutQuart * targetValue));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    const timeout = setTimeout(() => {
      requestAnimationFrame(animate);
    }, 500);

    return () => clearTimeout(timeout);
  }, [targetValue, duration]);

  return (
    <div className={`mb-4 ${className}`}>
      <div className="flex justify-between mb-1">
        <span className="text-[#00ff41] text-sm font-mono">{label}</span>
        <span className="text-[#00ffff] text-sm font-mono">{value}%</span>
      </div>
      <div className="matrix-progress">
        <div 
          className="matrix-progress-bar transition-all duration-100"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
};

export default MatrixProgress;
