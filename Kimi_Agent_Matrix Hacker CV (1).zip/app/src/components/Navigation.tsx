import { useState, useEffect } from 'react';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'SKILLS', href: '#skills' },
    { label: 'EXPERIENCE', href: '#experience' },
    { label: 'CERTS', href: '#certifications' },
    { label: 'ARTICLES', href: '#articles' },
    { label: 'CONTACT', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled 
            ? 'bg-[#0d0208]/95 border-b border-[#00ff41]/30 backdrop-blur-sm' 
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a 
              href="#" 
              className="text-[#00ff41] font-bold font-mono text-lg hover:neon-glow transition-all"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              <span className="text-[#00ffff]">⚡</span> MARCIO_MENDES
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => scrollToSection(item.href)}
                  className="px-4 py-2 text-sm font-mono text-[#00ff41]/70 hover:text-[#00ff41] 
                           hover:bg-[#00ff41]/10 transition-all duration-300 border border-transparent
                           hover:border-[#00ff41]/30"
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Status Indicator */}
            <div className="hidden md:flex items-center gap-2">
              <span className="w-2 h-2 bg-[#00ff41] rounded-full animate-pulse"></span>
              <span className="text-[#00ff41]/60 text-xs font-mono">AVAILABLE</span>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-[#00ff41] p-2"
            >
              <div className="space-y-1">
                <div className={`w-6 h-0.5 bg-[#00ff41] transition-all ${isMobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`}></div>
                <div className={`w-6 h-0.5 bg-[#00ff41] transition-all ${isMobileMenuOpen ? 'opacity-0' : ''}`}></div>
                <div className={`w-6 h-0.5 bg-[#00ff41] transition-all ${isMobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}></div>
              </div>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div 
        className={`fixed inset-0 z-40 bg-[#0d0208]/98 backdrop-blur-lg transition-all duration-300 md:hidden ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-6">
          {navItems.map((item, index) => (
            <button
              key={item.label}
              onClick={() => scrollToSection(item.href)}
              className="text-2xl font-mono text-[#00ff41] hover:text-[#00ffff] transition-colors"
              style={{ 
                animationDelay: `${index * 100}ms`,
                animation: isMobileMenuOpen ? 'fadeInUp 0.5s ease forwards' : 'none'
              }}
            >
              {item.label}
            </button>
          ))}
          <div className="mt-8 flex items-center gap-2">
            <span className="w-2 h-2 bg-[#00ff41] rounded-full animate-pulse"></span>
            <span className="text-[#00ff41]/60 text-sm font-mono">AVAILABLE FOR OPPORTUNITIES</span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </>
  );
};

export default Navigation;
