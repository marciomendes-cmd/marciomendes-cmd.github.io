import { useState, useEffect } from 'react';

const FooterSection = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <footer className="py-12 px-4 border-t border-[#00ff41]/30 bg-[#0d0208]">
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="text-2xl font-bold text-[#00ff41] neon-glow mb-4 font-mono">
              MARCIO_MENDES
            </div>
            <p className="text-[#00ff41]/60 text-sm mb-4 max-w-md">
              Vulnerability Management Analyst specializing in Qualys VMDR and Tenable.io. 
              7+ years securing enterprise environments with risk-based prioritization 
              and threat-informed defense.
            </p>
            <div className="flex items-center gap-4 text-sm">
              <span className="text-[#00ff41]/40">STATUS:</span>
              <span className="text-[#00ff41] flex items-center gap-2">
                <span className="w-2 h-2 bg-[#00ff41] rounded-full animate-pulse"></span>
                AVAILABLE FOR OPPORTUNITIES
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[#00ffff] font-bold mb-4 font-mono text-sm">
              :: NAVIGATION ::
            </h4>
            <ul className="space-y-2 text-sm">
              {[
                { label: 'Skills', href: '#skills' },
                { label: 'Experience', href: '#experience' },
                { label: 'Certifications', href: '#certifications' },
                { label: 'Articles', href: '#articles' },
                { label: 'Contact', href: '#contact' },
              ].map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href}
                    className="text-[#00ff41]/60 hover:text-[#00ff41] transition-colors"
                  >
                    ▸ {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* System Info */}
          <div>
            <h4 className="text-[#ffff00] font-bold mb-4 font-mono text-sm">
              :: SYSTEM_INFO ::
            </h4>
            <div className="space-y-2 text-sm font-mono">
              <div className="flex justify-between">
                <span className="text-[#00ff41]/40">VERSION:</span>
                <span className="text-[#00ff41]">v9.9.2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#00ff41]/40">BUILD:</span>
                <span className="text-[#00ff41]">PORTFOLIO_EDITION</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#00ff41]/40">UPTIME:</span>
                <span className="text-[#00ff41]">7+ YEARS</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#00ff41]/40">TIME:</span>
                <span className="text-[#00ff41]">
                  {currentTime.toLocaleTimeString('pt-BR')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ASCII Divider */}
        <div className="text-center mb-8">
          <pre className="text-[#00ff41]/20 text-xs font-mono hidden md:block">
{`
▓▒░═════════════════════════════════════════════════════════════════════════░▒▓
`}
          </pre>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-[#00ff41]/40 text-xs font-mono">
            <span>© 2024 MARCIO MENDES</span>
            <span className="mx-2">|</span>
            <span>VULNERABILITY MANAGEMENT ANALYST</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-[#00ff41]/40 text-xs font-mono">
              ENCRYPTED_CONNECTION
            </span>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-[#00ff41] rounded-full animate-pulse"></span>
              <span className="text-[#00ff41] text-xs font-mono">SECURE</span>
            </div>
          </div>
        </div>

        {/* Final Message */}
        <div className="mt-8 text-center">
          <p className="text-[#00ff41]/30 text-xs font-mono">
            "Security is not a product, but a process." — Bruce Schneier
          </p>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;
