import { useState, useRef, useEffect } from 'react';
import TerminalWindow from '../components/TerminalWindow';

interface Command {
  input: string;
  output: string[];
  type: 'success' | 'error' | 'info';
}

const availableCommands: Record<string, { output: string[]; type: 'success' | 'error' | 'info' }> = {
  'help': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║                    AVAILABLE COMMANDS                         ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  help          - Show this command list                      ║',
      '║  about         - About Marcio Mendes                         ║',
      '║  contact       - Contact information                         ║',
      '║  skills        - List technical skills                       ║',
      '║  experience    - Show work experience                        ║',
      '║  certs         - List certifications                       ║',
      '║  articles      - Show published articles                     ║',
      '║  download      - Download CV (PDF)                           ║',
      '║  linkedin      - Open LinkedIn profile                       ║',
      '║  whatsapp      - Contact via WhatsApp                        ║',
      '║  email         - Send email                                  ║',
      '║  clear         - Clear terminal                              ║',
      '║  status        - System status                               ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'info',
  },
  'about': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║              MARCIO MENDES - SECURITY PROFILE                ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  Role:        Vulnerability Management Analyst               ║',
      '║  Focus:       Security Operations (Qualys & Tenable)         ║',
      '║  Location:    São Paulo, Brazil (Remote Ready)               ║',
      '║  Experience:  7+ years in cybersecurity                      ║',
      '║  Education:   ITA - Postgraduate in InfoSec                  ║',
      '║                                                              ║',
      '║  Specializations:                                            ║',
      '║    • Risk-Based Vulnerability Prioritization                 ║',
      '║    • CVE/CVSS Analysis & Remediation                         ║',
      '║    • Threat-Informed Defense (MITRE ATT&CK)                  ║',
      '║    • Enterprise Security Operations                          ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'success',
  },
  'contact': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║                      CONTACT DETAILS                          ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  📧 Email:     marciomendes.ads@gmail.com                    ║',
      '║  📱 Phone:     +55 13 98140337                               ║',
      '║  💬 WhatsApp:  +55 13 98140337                               ║',
      '║  📍 Location:  São Paulo, Brazil                             ║',
      '║  💼 LinkedIn:  linkedin.com/in/this-marcio-qualys-vmdr/      ║',
      '║  📄 CV:        Download at /cv-marcio-mendes.pdf             ║',
      '║  🌐 Status:    Remote Ready | Available for opportunities    ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'success',
  },
  'skills': {
    output: [
      '>>> LOADING SKILL MATRIX...',
      '',
      'VULNERABILITY MANAGEMENT:',
      '  ▸ Qualys VMDR          [██████████] 95%',
      '  ▸ Tenable.io/sc        [█████████░] 90%',
      '  ▸ Risk Prioritization  [█████████░] 92%',
      '',
      'OFFENSIVE SECURITY:',
      '  ▸ Penetration Testing  [████████░░] 82%',
      '  ▸ MITRE ATT&CK         [█████████░] 88%',
      '  ▸ Burp Suite           [███████░░░] 78%',
      '',
      'RISK & COMPLIANCE:',
      '  ▸ FAIR/CRQ             [████████░░] 80%',
      '  ▸ ISO 27001            [█████████░] 88%',
      '  ▸ NIST Framework       [█████████░] 85%',
    ],
    type: 'success',
  },
  'experience': {
    output: [
      '>>> LOADING CAREER LOG...',
      '',
      '[CURRENT] ISH Tecnologia (12/2023 - 12/2025)',
      '  → Vulnerability Management Analyst',
      '  → Qualys VMDR & Tenable.io specialist',
      '',
      '[PREVIOUS] Metamorfose 9 (08/2018 - 12/2023)',
      '  → Lead System Administrator',
      '  → AWS | Windows Server | ISO 27001',
      '',
      '[PREVIOUS] Linkfort Telecom (01/2017 - 06/2017)',
      '  → Network Administrator',
      '',
      '[PREVIOUS] Morada da Praia (09/2007 - 06/2009)',
      '  → Network Administrator | Nessus pioneer',
      '',
      '>>> Total: 7+ years in cybersecurity',
    ],
    type: 'success',
  },
  'certs': {
    output: [
      '>>> LOADING CERTIFICATIONS...',
      '',
      'VULNERABILITY MANAGEMENT:',
      '  ✓ Qualys Certified Vulnerability Management Specialist',
      '  ✓ Tenable Vulnerability Management Specialist',
      '',
      'OFFENSIVE SECURITY:',
      '  ✓ Cisco Ethical Hacker',
      '  ✓ AttackIQ - Threat & Risk Management',
      '  ✓ API Penetration Testing',
      '',
      'RISK & COMPLIANCE:',
      '  ✓ FAIR™ Executive Communication & Governance',
      '  ✓ FEMA S-1300: Continuity of Operations',
      '',
      '>>> Total: 7 industry-recognized certifications',
    ],
    type: 'success',
  },
  'articles': {
    output: [
      '>>> LOADING PUBLISHED ARTICLES...',
      '',
      'PEERSPOT REVIEWS:',
      '  ▸ Asset Intelligence Transformed Risk Visibility',
      '  ▸ Unified Risk-Based Patching Reduces Vulnerabilities',
      '',
      'CASE STUDIES:',
      '  ▸ How I Prioritize Beyond CVSS Using Threat Intelligence',
      '',
      'BUG BOUNTY:',
      '  ▸ API Authorization Bypass Report',
      '',
      'WRITE-UPS:',
      '  ▸ Reducing MTTR: Automation in Vulnerability Management',
      '',
      '>>> Visit the Articles section for full content',
    ],
    type: 'success',
  },
  'download': {
    output: [
      '>>> INITIATING DOWNLOAD...',
      '',
      '📄 Marcio_Mendes_Vulnerability_Management_Analyst.pdf',
      '',
      '>>> File: cv-marcio-mendes.pdf',
      '>>> Size: ~2.4 MB',
      '>>> Format: PDF',
      '',
      '>>> Click the DOWNLOAD CV button below or visit:',
      '>>> /cv-marcio-mendes.pdf',
    ],
    type: 'info',
  },
  'linkedin': {
    output: [
      '>>> OPENING LINKEDIN PROFILE...',
      '',
      '🔗 https://www.linkedin.com/in/this-marcio-qualys-vmdr/',
      '',
      '>>> Connect with me on LinkedIn!',
    ],
    type: 'info',
  },
  'whatsapp': {
    output: [
      '>>> OPENING WHATSAPP...',
      '',
      '💬 https://wa.me/551398140337',
      '',
      '>>> Feel free to reach out on WhatsApp!',
      '>>> Available for quick responses during business hours',
    ],
    type: 'info',
  },
  'email': {
    output: [
      '>>> EMAIL CONTACT...',
      '',
      '📧 marciomendes.ads@gmail.com',
      '',
      '>>> Feel free to reach out for:',
      '    • Vulnerability Management opportunities',
      '    • Security Operations consulting',
      '    • Qualys/Tenable implementation',
      '',
      '>>> Response time: Usually within 24 hours',
    ],
    type: 'info',
  },
  'status': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║                    SYSTEM STATUS                              ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  STATUS:       🟢 AVAILABLE FOR OPPORTUNITIES                ║',
      '║  LOCATION:     São Paulo, Brazil (Remote Ready)              ║',
      '║  CLEARANCE:    Ready to start immediately                    ║',
      '║  PREFERENCES:  Remote / Hybrid positions                     ║',
      '║  FOCUS:        Vulnerability Management & Security Ops       ║',
      '║                                                              ║',
      '║  ████████████████████████████████████████ 100% READY        ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'success',
  },
  'clear': {
    output: ['>>> TERMINAL CLEARED'],
    type: 'info',
  },
};

const ContactSection = () => {
  const [commands, setCommands] = useState<Command[]>([
    {
      input: '',
      output: [
        '╔══════════════════════════════════════════════════════════════╗',
        '║     CYBER SECURITY TERMINAL v9.9 - Interactive Console       ║',
        '╠══════════════════════════════════════════════════════════════╣',
        '║  Type "help" to see available commands                       ║',
        '║  Type "contact" for direct contact information               ║',
        '║  Type "download" to get CV (PDF)                             ║',
        '║  Type "status" to check availability                         ║',
        '╚══════════════════════════════════════════════════════════════╝',
        '',
      ],
      type: 'info',
    },
  ]);
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [commands]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const cmd = input.toLowerCase().trim();
    
    if (cmd === 'clear') {
      setCommands([]);
      setInput('');
      return;
    }

    const commandData = availableCommands[cmd];
    
    if (commandData) {
      setCommands(prev => [...prev, {
        input: cmd,
        output: commandData.output,
        type: commandData.type,
      }]);
    } else if (cmd) {
      setCommands(prev => [...prev, {
        input: cmd,
        output: [
          `Command not recognized: "${cmd}"`,
          'Type "help" to see available commands.',
        ],
        type: 'error',
      }]);
    }

    setInput('');
  };

  const getOutputColor = (type: string) => {
    switch(type) {
      case 'success': return 'text-[#00ff41]';
      case 'error': return 'text-[#ff0040]';
      case 'info': return 'text-[#00ffff]';
      default: return 'text-[#00ff41]';
    }
  };

  return (
    <section id="contact" className="py-20 px-4 relative">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-block border border-[#00ff41]/50 px-4 py-2 mb-4 bg-[#00ff41]/5">
            <span className="text-[#00ff41] font-mono text-sm">MODULE_06: CONTACT_TERMINAL</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ff41] neon-glow mb-4">
            GET IN TOUCH
          </h2>
          <p className="text-[#00ff41]/70 text-lg font-mono">
            Use the interactive terminal to access contact information or 
            type commands to learn more about my profile.
          </p>
        </div>

        {/* Terminal */}
        <TerminalWindow 
          title="visitor@marcio-mendes:~$" 
          className="min-h-[500px]"
        >
          <div 
            ref={terminalRef}
            className="h-[400px] overflow-y-auto font-mono text-sm space-y-4"
          >
            {commands.map((cmd, index) => (
              <div key={index}>
                {cmd.input && (
                  <div className="flex items-center gap-2 text-[#00ff41]/50">
                    <span>visitor@marcio-mendes:~$</span>
                    <span className="text-[#00ff41]">{cmd.input}</span>
                  </div>
                )}
                <div className={getOutputColor(cmd.type)}>
                  {cmd.output.map((line, lineIndex) => (
                    <div key={lineIndex} className="whitespace-pre">
                      {line}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            {/* Input Line */}
            <form onSubmit={handleSubmit} className="flex items-center gap-2">
              <span className="text-[#00ff41]/50">visitor@marcio-mendes:~$</span>
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-[#00ff41] font-mono"
                placeholder="Type a command..."
                autoFocus
              />
              <span className="cursor-blink text-[#00ff41]">_</span>
            </form>
          </div>
        </TerminalWindow>

        {/* Quick Commands */}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {['help', 'about', 'contact', 'skills', 'experience', 'certs', 'articles', 'download', 'status'].map((cmd) => (
            <button
              key={cmd}
              onClick={() => {
                setInput(cmd);
                inputRef.current?.focus();
              }}
              className="px-4 py-2 border border-[#00ff41]/30 text-[#00ff41]/60 
                         hover:border-[#00ff41] hover:text-[#00ff41] text-sm font-mono
                         transition-all duration-300"
            >
              {cmd}
            </button>
          ))}
        </div>

        {/* Direct Contact Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <a 
            href="mailto:marciomendes.ads@gmail.com"
            className="p-5 border border-[#00ff41]/30 bg-[#00ff41]/5 rounded-lg text-center
                       hover:border-[#00ff41] hover:bg-[#00ff41]/10 transition-all"
          >
            <div className="text-2xl mb-2">📧</div>
            <div className="text-[#00ff41] font-bold text-sm">EMAIL</div>
            <div className="text-[#00ff41]/60 text-xs mt-1">marciomendes.ads@gmail.com</div>
          </a>
          
          <a 
            href="https://wa.me/551398140337"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 border border-[#25d366]/30 bg-[#25d366]/5 rounded-lg text-center
                       hover:border-[#25d366] hover:bg-[#25d366]/10 transition-all"
          >
            <div className="text-2xl mb-2">💬</div>
            <div className="text-[#25d366] font-bold text-sm">WHATSAPP</div>
            <div className="text-[#00ff41]/60 text-xs mt-1">+55 13 98140337</div>
          </a>
          
          <a 
            href="https://www.linkedin.com/in/this-marcio-qualys-vmdr/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg text-center
                       hover:border-[#00ffff] hover:bg-[#00ffff]/10 transition-all"
          >
            <div className="text-2xl mb-2">💼</div>
            <div className="text-[#00ffff] font-bold text-sm">LINKEDIN</div>
            <div className="text-[#00ff41]/60 text-xs mt-1">/in/this-marcio-qualys-vmdr</div>
          </a>
          
          <a 
            href="/cv-marcio-mendes.pdf"
            download="Marcio_Mendes_Vulnerability_Management_Analyst.pdf"
            className="p-5 border border-[#ffff00]/30 bg-[#ffff00]/5 rounded-lg text-center
                       hover:border-[#ffff00] hover:bg-[#ffff00]/10 transition-all group"
          >
            <div className="text-2xl mb-2 group-hover:animate-bounce">📄</div>
            <div className="text-[#ffff00] font-bold text-sm">DOWNLOAD CV</div>
            <div className="text-[#00ff41]/60 text-xs mt-1">PDF Format</div>
          </a>
          
          <div className="p-5 border border-[#ff00ff]/30 bg-[#ff00ff]/5 rounded-lg text-center">
            <div className="text-2xl mb-2">📍</div>
            <div className="text-[#ff00ff] font-bold text-sm">LOCATION</div>
            <div className="text-[#00ff41]/60 text-xs mt-1">São Paulo, Brazil<br/>Remote Ready</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
