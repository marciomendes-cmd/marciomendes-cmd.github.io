import { useState, useEffect } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import TypewriterText from '../components/TypewriterText';
import MatrixProgress from '../components/MatrixProgress';

interface NLPModel {
  id: string;
  name: string;
  description: string;
  application: string;
}

const nlpModels: NLPModel[] = [
  {
    id: 'VAK',
    name: 'SISTEMAS REPRESENTACIONAIS (VAK)',
    description: 'Visual, Auditivo e Cinestésico. Identifique como a pessoa processa informações.',
    application: 'Observe os predicados linguísticos. Pessoas visuais usam palavras como "ver", "claro", "imagem". Auditivos: "ouvir", "som", "harmonia". Cinestésicos: "sentir", "tato", "conforto".',
  },
  {
    id: 'RAPPORT',
    name: 'RAPPORT E EMPATIA',
    description: 'Criação de conexão profunda através da espelhamento e sincronização.',
    application: 'Espelhe a postura, respiração, tom de voz e ritmo de fala da pessoa. Não imite, sincronize sutilmente para criar familiaridade inconsciente.',
  },
  {
    id: 'ANCHORING',
    name: 'ÂNCORAS EMOCIONAIS',
    description: 'Disparar estados emocionais específicos através de estímulos associados.',
    application: 'Associe um toque, palavra ou gesto a um estado emocional positivo. No momento certo, dispare a âncora para reativar aquele estado.',
  },
  {
    id: 'REFRAMING',
    name: 'REFRAMING (REENQUADRAMENTO)',
    description: 'Mudar o contexto ou significado de uma experiência para alterar sua percepção.',
    application: 'Transforme objeções em oportunidades. "É caro" vira "É um investimento que se paga". "É difícil" vira "É desafiador e gratificante".',
  },
  {
    id: 'MILTON',
    name: 'MODELO DE MILTON',
    description: 'Padrões de linguagem hipnótica para induzir estados alterados de consciência.',
    application: 'Use ambiguidades, suposições pressupostas, citações embutidas e frases em dupla vinculação para contornar resistências conscientes.',
  },
  {
    id: 'META',
    name: 'PROGRAMAS METÁFORICOS',
    description: 'Identificar os filtros mentais que determinam como as pessoas tomam decisões.',
    application: 'Descubra se a pessoa é pró-ativa ou reativa, se foca em opções ou procedimentos, se pensa em detalhes ou no big picture.',
  },
];

const PNLSection = () => {
  const [activeModel, setActiveModel] = useState<string>('VAK');
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const activeNLP = nlpModels.find(m => m.id === activeModel);

  return (
    <section className="py-20 px-4 relative bg-gradient-to-b from-transparent via-[#00ff41]/5 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#00ffff]/50 px-4 py-2 mb-4 bg-[#00ffff]/5">
            <span className="text-[#00ffff] font-mono text-sm">MÓDULO_02: PNL_AVANÇADA</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ffff] neon-glow-cyan mb-4">
            PROGRAMAÇÃO NEUROLINGUÍSTICA
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Técnicas de Márcio Mendes e mestres da PNL para reprogramar mentes 
            e criar resultados extraordinários.
          </p>
        </div>

        {/* PNL Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar Menu */}
          <div className="lg:col-span-1">
            <TerminalWindow title="pnl@models:~$ ls -la" className="h-full">
              <div className="space-y-2">
                {nlpModels.map((model) => (
                  <button
                    key={model.id}
                    onClick={() => setActiveModel(model.id)}
                    className={`w-full text-left p-3 rounded transition-all duration-300 font-mono text-sm ${
                      activeModel === model.id
                        ? 'bg-[#00ffff]/20 border border-[#00ffff] text-[#00ffff]'
                        : 'text-[#00ff41]/60 hover:bg-[#00ff41]/10 hover:text-[#00ff41]'
                    }`}
                  >
                    <span className="mr-2">{activeModel === model.id ? '▶' : ' '}</span>
                    {model.name}
                  </button>
                ))}
              </div>
            </TerminalWindow>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <TerminalWindow 
              title={`pnl@execute:~/${activeModel.toLowerCase()}`}
              className="h-full"
            >
              {activeNLP && showContent && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-[#00ffff] mb-4">
                      <TypewriterText 
                        text={activeNLP.name} 
                        delay={30}
                        showCursor={false}
                      />
                    </h3>
                    <p className="text-[#00ff41]/80 text-lg leading-relaxed">
                      {activeNLP.description}
                    </p>
                  </div>

                  <div className="border-t border-[#00ff41]/30 pt-6">
                    <h4 className="text-[#ffff00] font-bold mb-4 flex items-center gap-2">
                      <span>⚡</span>
                      <span>APLICAÇÃO_PRÁTICA</span>
                    </h4>
                    <p className="text-[#00ff41]/70 leading-relaxed">
                      {activeNLP.application}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 pt-4">
                    <div className="text-xs text-[#00ff41]/50">
                      STATUS: <span className="text-[#00ff41]">ATIVO</span>
                    </div>
                    <div className="flex-1 h-px bg-[#00ff41]/20"></div>
                    <div className="text-xs text-[#00ff41]/50">
                      ID: {activeModel}_001
                    </div>
                  </div>
                </div>
              )}
            </TerminalWindow>
          </div>
        </div>

        {/* Skills Progress */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-[#00ff41] mb-8 text-center">
            :: NÍVEIS_DE_DOMÍNIO ::
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <MatrixProgress label="LINGUAGEM_PERSUASIVA" targetValue={95} />
            <MatrixProgress label="LEITURA_COMPORTAMENTAL" targetValue={88} />
            <MatrixProgress label="ÂNCORAS_EMOCIONAIS" targetValue={92} />
            <MatrixProgress label="RAPPORT_AVANÇADO" targetValue={87} />
          </div>
        </div>

        {/* Márcio Mendes Quote */}
        <div className="mt-16 p-8 border border-[#ff00ff]/30 bg-[#ff00ff]/5 rounded-lg">
          <div className="flex items-start gap-4">
            <div className="text-4xl text-[#ff00ff]">❝</div>
            <div>
              <p className="text-xl text-[#ff00ff] font-mono italic mb-4">
                "A PNL não é sobre manipulação. É sobre compreensão profunda 
                do funcionamento da mente humana e usar esse conhecimento 
                para criar mudanças positivas na vida das pessoas."
              </p>
              <cite className="text-[#00ff41]/60 font-mono not-italic">
                — Márcio Mendes, Mestre em PNL
              </cite>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PNLSection;
