import { useState } from 'react';
import HolographicCard from '../components/HolographicCard';
import TerminalWindow from '../components/TerminalWindow';

interface Certification {
  id: number;
  name: string;
  issuer: string;
  year: string;
  category: 'vulnerability' | 'risk' | 'offensive' | 'compliance';
  description: string;
  verified: boolean;
}

const certifications: Certification[] = [
  {
    id: 1,
    name: 'Qualys Certified Vulnerability Management Specialist',
    issuer: 'Qualys',
    year: '2024',
    category: 'vulnerability',
    description: 'Expert-level certification in Qualys VMDR platform, asset discovery, and vulnerability remediation workflows.',
    verified: true,
  },
  {
    id: 2,
    name: 'Tenable Vulnerability Management Specialist',
    issuer: 'Tenable',
    year: '2024',
    category: 'vulnerability',
    description: 'Specialized certification in Tenable.io and Tenable.sc platforms for enterprise vulnerability management.',
    verified: true,
  },
  {
    id: 3,
    name: 'Executive Communication and Governance with FAIR™',
    issuer: 'FAIR Institute',
    year: '2026',
    category: 'risk',
    description: 'Advanced training in Factor Analysis of Information Risk (FAIR) framework for quantitative risk analysis.',
    verified: true,
  },
  {
    id: 4,
    name: 'Cisco Ethical Hacker',
    issuer: 'Cisco',
    year: '2023',
    category: 'offensive',
    description: 'Certification in ethical hacking methodologies, penetration testing, and vulnerability assessment.',
    verified: true,
  },
  {
    id: 5,
    name: 'AttackIQ - Uniting Threat and Risk Management',
    issuer: 'AttackIQ',
    year: '2024',
    category: 'offensive',
    description: 'Purple team approach integrating NIST and MITRE ATT&CK frameworks for threat-informed defense.',
    verified: true,
  },
  {
    id: 6,
    name: 'API Penetration Testing',
    issuer: 'Security Certification',
    year: '2024',
    category: 'offensive',
    description: 'Specialized training in API security testing, OWASP API Top 10, and REST/GraphQL vulnerability assessment.',
    verified: true,
  },
  {
    id: 7,
    name: 'S-1300: Introduction to Continuity of Operations',
    issuer: 'FEMA',
    year: '2023',
    category: 'compliance',
    description: 'Federal Emergency Management Agency certification for business continuity and disaster recovery planning.',
    verified: true,
  },
];

const categoryColors = {
  vulnerability: 'green',
  risk: 'purple',
  offensive: 'cyan',
  compliance: 'yellow',
} as const;

const categoryLabels = {
  vulnerability: 'VULNERABILITY MANAGEMENT',
  risk: 'RISK & GOVERNANCE',
  offensive: 'OFFENSIVE SECURITY',
  compliance: 'COMPLIANCE',
};

const CertificationsSection = () => {
  const [selectedCert, setSelectedCert] = useState<Certification | null>(null);
  const [filter, setFilter] = useState<string>('ALL');

  const filters = ['ALL', 'vulnerability', 'risk', 'offensive', 'compliance'];

  const filteredCerts = filter === 'ALL' 
    ? certifications 
    : certifications.filter(c => c.category === filter);

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#ff00ff]/50 px-4 py-2 mb-4 bg-[#ff00ff]/5">
            <span className="text-[#ff00ff] font-mono text-sm">MODULE_03: CREDENTIALS</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#ff00ff] neon-glow-purple mb-4">
            CERTIFICATIONS
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Industry-recognized certifications validating expertise in vulnerability management, 
            risk assessment, and offensive security.
          </p>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-6 mb-12">
          <div className="text-center p-4 border border-[#00ff41]/30 bg-[#00ff41]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#00ff41]">{certifications.length}</div>
            <div className="text-xs text-[#00ff41]/60">TOTAL CERTS</div>
          </div>
          <div className="text-center p-4 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#00ffff]">2</div>
            <div className="text-xs text-[#00ff41]/60">VENDOR CERTS</div>
          </div>
          <div className="text-center p-4 border border-[#ff00ff]/30 bg-[#ff00ff]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#ff00ff]">3</div>
            <div className="text-xs text-[#00ff41]/60">OFFENSIVE</div>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 font-mono text-xs border transition-all duration-300 ${
                filter === f
                  ? 'bg-[#ff00ff]/20 border-[#ff00ff] text-[#ff00ff]'
                  : 'border-[#00ff41]/30 text-[#00ff41]/60 hover:border-[#00ff41] hover:text-[#00ff41]'
              }`}
            >
              {f === 'ALL' ? 'ALL CERTIFICATIONS' : categoryLabels[f as keyof typeof categoryLabels]}
            </button>
          ))}
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCerts.map((cert) => (
            <div
              key={cert.id}
              onClick={() => setSelectedCert(cert)}
              className="cursor-pointer"
            >
              <HolographicCard
                title={cert.name}
                icon={cert.verified ? '✓' : '○'}
                glowColor={categoryColors[cert.category]}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#00ffff] text-sm">{cert.issuer}</span>
                    <span className="text-[#00ff41]/50 text-xs">{cert.year}</span>
                  </div>
                  <p className="text-[#00ff41]/60 text-sm line-clamp-2">
                    {cert.description}
                  </p>
                  <div className="flex items-center gap-2">
                    {cert.verified && (
                      <span className="px-2 py-1 text-xs bg-[#00ff41]/20 text-[#00ff41]">
                        VERIFIED
                      </span>
                    )}
                    <span className="text-[#00ff41]/50 text-xs ml-auto">
                      CLICK FOR DETAILS →
                    </span>
                  </div>
                </div>
              </HolographicCard>
            </div>
          ))}
        </div>

        {/* Selected Cert Detail */}
        {selectedCert && (
          <TerminalWindow
            title={`cert@verify:~/${selectedCert.name.toLowerCase().replace(/\s+/g, '_').substring(0, 20)}`}
            className="max-w-3xl mx-auto mt-12"
          >
            <div className="space-y-6">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-bold text-[#ff00ff]">{selectedCert.name}</h3>
                  <p className="text-[#00ffff]">{selectedCert.issuer}</p>
                </div>
                <div className="text-right">
                  <span className="text-[#00ff41]/50 text-sm">{selectedCert.year}</span>
                  {selectedCert.verified && (
                    <div className="text-[#00ff41] text-xs mt-1">✓ VERIFIED</div>
                  )}
                </div>
              </div>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#ffff00] font-bold mb-3">:: CERTIFICATION_DETAILS ::</h4>
                <p className="text-[#00ff41]/70">{selectedCert.description}</p>
              </div>

              <div className="flex items-center gap-4">
                <span className="text-[#00ff41]/50 text-sm">CATEGORY:</span>
                <span 
                  className="px-3 py-1 text-sm border"
                  style={{ 
                    color: categoryColors[selectedCert.category],
                    borderColor: categoryColors[selectedCert.category]
                  }}
                >
                  {categoryLabels[selectedCert.category]}
                </span>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setSelectedCert(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [CLOSE]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}
      </div>
    </section>
  );
};

export default CertificationsSection;
