import { useState, useRef, useEffect } from 'react';
import TerminalWindow from '../components/TerminalWindow';

interface Command {
  input: string;
  output: string[];
  type: 'success' | 'error' | 'info';
}

const availableCommands: Record<string, { output: string[]; type: 'success' | 'error' | 'info' }> = {
  'help': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║                    COMANDOS DISPONÍVEIS                       ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  help          - Mostra esta lista de comandos               ║',
      '║  about         - Sobre o Cyber Neural Interface              ║',
      '║  cialdini      - Lista os 6 princípios de influência         ║',
      '║  pnl           - Mostra modelos de PNL disponíveis           ║',
      '║  neuro         - Exibe técnicas de neuromarketing            ║',
      '║  carnegie      - Princípios de relacionamentos               ║',
      '║  clear         - Limpa o terminal                            ║',
      '║  matrix        - Ativa o modo Matrix                         ║',
      '║  status        - Status do sistema                           ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'info',
  },
  'about': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║              CYBER NEURAL INTERFACE v9.9                     ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  Sistema de treinamento em influência e persuasão            ║',
      '║  Baseado em:                                                 ║',
      '║    • Princípios de Robert Cialdini                           ║',
      '║    • Programação Neurolinguística (Márcio Mendes)            ║',
      '║    • Neuromarketing (Priming & Framing)                      ║',
      '║    • Relacionamentos Interpessoais (Dale Carnegie)           ║',
      '║                                                              ║',
      '║  Desenvolvido por: Marcio Mendes & Neural Network            ║',
      '║  Status: SISTEMA OPERACIONAL                                 ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'success',
  },
  'cialdini': {
    output: [
      '>>> CARREGANDO MÓDULO: CIALDINI...',
      '',
      '[1] RECIPROCIDADE    - Dar para receber',
      '[2] COMPROMISSO      - Consistência de ações',
      '[3] PROVA SOCIAL     - Seguir o grupo',
      '[4] AUTORIDADE       - Obediência a especialistas',
      '[5] GOSTO            - Afinidade gera influência',
      '[6] ESCASSEZ         - Oportunidades limitadas',
      '',
      '>>> Use "scroll" para ver detalhes na seção Cialdini',
    ],
    type: 'success',
  },
  'pnl': {
    output: [
      '>>> CARREGANDO MÓDULO: PNL...',
      '',
      'MODELOS DISPONÍVEIS:',
      '  ▸ VAK         - Sistemas representacionais',
      '  ▸ RAPPORT     - Criação de conexão',
      '  ▸ ANCHORING   - Âncoras emocionais',
      '  ▸ REFRAMING   - Reenquadramento',
      '  ▸ MILTON      - Modelo Milton Erickson',
      '  ▸ META        - Programas metafóricos',
      '',
      '>>> Use "scroll" para ver detalhes na seção PNL',
    ],
    type: 'success',
  },
  'neuro': {
    output: [
      '>>> CARREGANDO MÓDULO: NEUROMARKETING...',
      '',
      'TÉCNICAS DE INFLUÊNCIA INCONSCIENTE:',
      '  ▸ PRIMING SEMÂNTICO    - Ativação por palavras',
      '  ▸ PRIMING AFETIVO      - Ativação emocional',
      '  ▸ FRAMING POSITIVO     - Destacar ganhos',
      '  ▸ FRAMING NEGATIVO     - Aversão à perda',
      '  ▸ ÂNCORA DE PREÇO      - Contextualização',
      '  ▸ EFEITO DE CONTRASTE  - Percepção relativa',
      '',
      '>>> Use "scroll" para ver detalhes na seção Neuromarketing',
    ],
    type: 'success',
  },
  'carnegie': {
    output: [
      '>>> CARREGANDO MÓDULO: CARNEGIE...',
      '',
      '8 PRINCÍPIOS FUNDAMENTAIS:',
      '  01. Não critique, condene ou reclame',
      '  02. Dê elogios sinceros',
      '  03. Desperte desejos vividos',
      '  04. Torne-se genuinamente interessado',
      '  05. Sorria de forma autêntica',
      '  06. Lembre-se dos nomes',
      '  07. Incentive os outros a falarem',
      '  08. Fale sobre o que interessa a eles',
      '',
      '>>> Use "scroll" para ver detalhes na seção Carnegie',
    ],
    type: 'success',
  },
  'matrix': {
    output: [
      '>>> INICIANDO SEQUÊNCIA MATRIX...',
      '',
      'Wake up, Neo...',
      'The Matrix has you...',
      'Follow the white rabbit.',
      '',
      'Knock, knock, Neo.',
      '',
      '>>> MODO MATRIX ATIVADO',
      '>>> Red pill escolhida. Não há volta.',
    ],
    type: 'info',
  },
  'status': {
    output: [
      '╔══════════════════════════════════════════════════════════════╗',
      '║                    STATUS DO SISTEMA                          ║',
      '╠══════════════════════════════════════════════════════════════╣',
      '║  CPU:        23% utilizado                                   ║',
      '║  MEMÓRIA:    4.2GB / 16GB                                    ║',
      '║  REDE:       Conectado (SSL)                                 ║',
      '║  MÓDULOS:    4/4 ativos                                      ║',
      '║  DATABASE:   Sincronizado                                    ║',
      '║  ENCRYPTION: AES-256 ativo                                   ║',
      '║                                                              ║',
      '║  ████████████████████████████████████████ 100% ONLINE       ║',
      '╚══════════════════════════════════════════════════════════════╝',
    ],
    type: 'success',
  },
  'clear': {
    output: ['>>> TERMINAL LIMPO'],
    type: 'info',
  },
};

const CommandSection = () => {
  const [commands, setCommands] = useState<Command[]>([
    {
      input: '',
      output: [
        '╔══════════════════════════════════════════════════════════════╗',
        '║     CYBER NEURAL INTERFACE v9.9 - Terminal Interativo        ║',
        '╠══════════════════════════════════════════════════════════════╣',
        '║  Digite "help" para ver os comandos disponíveis              ║',
        '║  Use o terminal para acessar informações rapidamente         ║',
        '╚══════════════════════════════════════════════════════════════╝',
        '',
      ],
      type: 'info',
    },
  ]);
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [commands]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const cmd = input.toLowerCase().trim();
    
    if (cmd === 'clear') {
      setCommands([]);
      setInput('');
      return;
    }

    const commandData = availableCommands[cmd];
    
    if (commandData) {
      setCommands(prev => [...prev, {
        input: cmd,
        output: commandData.output,
        type: commandData.type,
      }]);
    } else if (cmd) {
      setCommands(prev => [...prev, {
        input: cmd,
        output: [
          `Comando não reconhecido: "${cmd}"`,
          'Digite "help" para ver os comandos disponíveis.',
        ],
        type: 'error',
      }]);
    }

    setInput('');
  };

  const getOutputColor = (type: string) => {
    switch(type) {
      case 'success': return 'text-[#00ff41]';
      case 'error': return 'text-[#ff0040]';
      case 'info': return 'text-[#00ffff]';
      default: return 'text-[#00ff41]';
    }
  };

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-block border border-[#00ff41]/50 px-4 py-2 mb-4 bg-[#00ff41]/5">
            <span className="text-[#00ff41] font-mono text-sm">TERMINAL_INTERATIVO</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ff41] neon-glow mb-4">
            INTERFACE DE COMANDO
          </h2>
          <p className="text-[#00ff41]/70 text-lg font-mono">
            Acesse o conhecimento diretamente pelo terminal. 
            Digite comandos para explorar os módulos.
          </p>
        </div>

        {/* Terminal */}
        <TerminalWindow 
          title="user@cyber-neural:~$" 
          className="min-h-[500px]"
        >
          <div 
            ref={terminalRef}
            className="h-[400px] overflow-y-auto font-mono text-sm space-y-4"
          >
            {commands.map((cmd, index) => (
              <div key={index}>
                {cmd.input && (
                  <div className="flex items-center gap-2 text-[#00ff41]/50">
                    <span>user@cyber-neural:~$</span>
                    <span className="text-[#00ff41]">{cmd.input}</span>
                  </div>
                )}
                <div className={getOutputColor(cmd.type)}>
                  {cmd.output.map((line, lineIndex) => (
                    <div key={lineIndex} className="whitespace-pre">
                      {line}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            {/* Input Line */}
            <form onSubmit={handleSubmit} className="flex items-center gap-2">
              <span className="text-[#00ff41]/50">user@cyber-neural:~$</span>
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-[#00ff41] font-mono"
                placeholder="Digite um comando..."
                autoFocus
              />
              <span className="cursor-blink text-[#00ff41]">_</span>
            </form>
          </div>
        </TerminalWindow>

        {/* Quick Commands */}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {['help', 'about', 'cialdini', 'pnl', 'neuro', 'carnegie', 'status'].map((cmd) => (
            <button
              key={cmd}
              onClick={() => {
                setInput(cmd);
                inputRef.current?.focus();
              }}
              className="px-4 py-2 border border-[#00ff41]/30 text-[#00ff41]/60 
                         hover:border-[#00ff41] hover:text-[#00ff41] text-sm font-mono
                         transition-all duration-300"
            >
              {cmd}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CommandSection;
