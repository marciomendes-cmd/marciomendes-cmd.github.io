import { useState } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import GlitchText from '../components/GlitchText';

interface Technique {
  id: string;
  name: string;
  category: 'PRIMING' | 'FRAMING' | 'COGNITIVE_BIAS';
  description: string;
  examples: string[];
  impact: string;
}

const techniques: Technique[] = [
  {
    id: 'semantic',
    name: 'PRIMING SEMÂNTICO',
    category: 'PRIMING',
    description: 'Ativação inconsciente de conceitos relacionados através de palavras ou imagens.',
    examples: [
      'Usar palavras como "premium", "exclusivo" antes de mostrar preços',
      'Imagens de luxo antes de apresentar um produto',
      'Cores que evocam emoções específicas',
    ],
    impact: 'ALTO - Afeta percepção de valor em 40-60%',
  },
  {
    id: 'affective',
    name: 'PRIMING AFETIVO',
    category: 'PRIMING',
    description: 'Ativação de estados emocionais que influenciam decisões subsequentes.',
    examples: [
      'Música ambiente que cria o humor desejado',
      'Cores quentes para urgência, frias para confiança',
      'Stories que evocam empatia antes do pitch',
    ],
    impact: 'MUITO ALTO - Emoções ditam 95% das decisões',
  },
  {
    id: 'positive',
    name: 'FRAMING POSITIVO',
    category: 'FRAMING',
    description: 'Apresentar informações destacando ganhos e benefícios.',
    examples: [
      '"Economize 20%" ao invés de "Pague 80%"',
      '"90% livre de gordura" vs "10% gordura"',
      'Focar no que o cliente ganha, não no que gasta',
    ],
    impact: 'ALTO - Aumenta conversão em 25-35%',
  },
  {
    id: 'negative',
    name: 'FRAMING NEGATIVO (LOSS)',
    category: 'FRAMING',
    description: 'Destacar o que a pessoa pode perder se não agir.',
    examples: [
      '"Não perca esta oportunidade única"',
      '"Últimas unidades disponíveis"',
      '"Preço volta ao normal em 24h"',
    ],
    impact: 'MUITO ALTO - Aversão à perda é 2x mais forte',
  },
  {
    id: 'anchoring',
    name: 'ÂNCORA DE PREÇO',
    category: 'COGNITIVE_BIAS',
    description: 'O primeiro número apresentado influencia todas as percepções subsequentes.',
    examples: [
      'Mostrar preço alto primeiro, depois o "real"',
      'Planos com preços decrescentes de valor',
      'Comparar com concorrentes mais caros',
    ],
    impact: 'CRÍTICO - Define todo o contexto de valor',
  },
  {
    id: 'contrast',
    name: 'EFEITO DE CONTRASTE',
    category: 'COGNITIVE_BIAS',
    description: 'A percepção é relativa ao contexto imediato.',
    examples: [
      'Produto "premium" ao lado do "básico"',
      'Preço de 3x parece pequeno após mostrar o total',
      'Antes/depois dramáticos',
    ],
    impact: 'ALTO - Muda percepção em até 300%',
  },
];

const NeuromarketingSection = () => {
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [selectedTech, setSelectedTech] = useState<Technique | null>(null);

  const categories = ['ALL', 'PRIMING', 'FRAMING', 'COGNITIVE_BIAS'];

  const filteredTechniques = activeCategory === 'ALL' 
    ? techniques 
    : techniques.filter(t => t.category === activeCategory);

  const getCategoryColor = (cat: string) => {
    switch(cat) {
      case 'PRIMING': return '#00ff41';
      case 'FRAMING': return '#00ffff';
      case 'COGNITIVE_BIAS': return '#ff00ff';
      default: return '#ffff00';
    }
  };

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#ff00ff]/50 px-4 py-2 mb-4 bg-[#ff00ff]/5">
            <span className="text-[#ff00ff] font-mono text-sm">MÓDULO_03: NEUROMARKETING</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#ff00ff] neon-glow-purple mb-4">
            <GlitchText text="PRIMING & FRAMING" glitchInterval={3500} />
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Hackeie o cérebro limbico. Use priming e framing para criar 
            percepções favoráveis antes mesmo da decisão consciente.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-3 font-mono text-sm border transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-[#ff00ff]/20 border-[#ff00ff] text-[#ff00ff]'
                  : 'border-[#00ff41]/30 text-[#00ff41]/60 hover:border-[#00ff41] hover:text-[#00ff41]'
              }`}
            >
              {cat === 'ALL' ? 'TODOS' : cat}
            </button>
          ))}
        </div>

        {/* Techniques Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredTechniques.map((tech) => (
            <div
              key={tech.id}
              onClick={() => setSelectedTech(tech)}
              className="p-6 border border-[#00ff41]/30 bg-[#00ff41]/5 rounded-lg cursor-pointer 
                         hover:border-[#ff00ff] hover:bg-[#ff00ff]/5 transition-all duration-300
                         hover:shadow-[0_0_20px_rgba(255,0,255,0.3)]"
            >
              <div 
                className="text-xs font-mono mb-3"
                style={{ color: getCategoryColor(tech.category) }}
              >
                [{tech.category}]
              </div>
              <h3 className="text-lg font-bold text-[#00ff41] mb-3">
                {tech.name}
              </h3>
              <p className="text-[#00ff41]/60 text-sm mb-4">
                {tech.description.substring(0, 80)}...
              </p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#ffff00]">
                  IMPACTO: {tech.impact.split(' - ')[0]}
                </span>
                <span className="text-[#00ff41]/50 text-sm">→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Technique Detail */}
        {selectedTech && (
          <TerminalWindow
            title={`neuro@technique:~/${selectedTech.id}`}
            className="max-w-4xl mx-auto"
          >
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-[#ff00ff]">
                  {selectedTech.name}
                </h3>
                <span 
                  className="px-3 py-1 text-xs font-mono border"
                  style={{ 
                    color: getCategoryColor(selectedTech.category),
                    borderColor: getCategoryColor(selectedTech.category)
                  }}
                >
                  {selectedTech.category}
                </span>
              </div>

              <p className="text-[#00ff41]/80 text-lg">
                {selectedTech.description}
              </p>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#00ffff] font-bold mb-4">:: EXEMPLOS_DE_APLICAÇÃO ::</h4>
                <ul className="space-y-3">
                  {selectedTech.examples.map((example, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className="text-[#00ff41] mt-1">▸</span>
                      <span className="text-[#00ff41]/70">{example}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#ffff00]/10 border border-[#ffff00]/30 p-4 rounded">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[#ffff00]">⚡</span>
                  <span className="text-[#ffff00] font-bold">IMPACTO_MENSURADO</span>
                </div>
                <p className="text-[#ffff00]/80">{selectedTech.impact}</p>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setSelectedTech(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [FECHAR]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}

        {/* Brain Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'DECISÕES INCONSCIENTES', value: '95%', color: '#ff00ff' },
            { label: 'TEMPO DE DECISÃO', value: '0.2s', color: '#00ffff' },
            { label: 'MEMÓRIA VISUAL', value: '80%', color: '#00ff41' },
            { label: 'IMPACTO EMOCIONAL', value: '3x', color: '#ffff00' },
          ].map((stat, index) => (
            <div 
              key={index}
              className="text-center p-6 border border-[#00ff41]/20 bg-[#00ff41]/5 rounded-lg"
            >
              <div 
                className="text-3xl md:text-4xl font-bold font-mono mb-2"
                style={{ color: stat.color, textShadow: `0 0 10px ${stat.color}` }}
              >
                {stat.value}
              </div>
              <div className="text-xs text-[#00ff41]/60">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NeuromarketingSection;
