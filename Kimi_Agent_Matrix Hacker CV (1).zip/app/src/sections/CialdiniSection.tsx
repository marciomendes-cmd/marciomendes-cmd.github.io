import { useState } from 'react';
import HolographicCard from '../components/HolographicCard';
import TerminalWindow from '../components/TerminalWindow';
import TypewriterText from '../components/TypewriterText';

interface Principle {
  id: number;
  name: string;
  icon: string;
  color: 'green' | 'cyan' | 'purple' | 'yellow';
  description: string;
  techniques: string[];
}

const principles: Principle[] = [
  {
    id: 1,
    name: 'RECIPROCIDADE',
    icon: '⇄',
    color: 'green',
    description: 'O princípio da reciprocidade estabelece que as pessoas se sentem obrigadas a retribuir favores, presentes ou gentilezas recebidas.',
    techniques: [
      'Ofereça valor antes de pedir algo',
      'Use amostras grátis estrategicamente',
      'Crie conteúdo de valor gratuito',
      'Faça favores inesperados',
    ],
  },
  {
    id: 2,
    name: 'COMPROMISSO',
    icon: '✓',
    color: 'cyan',
    description: 'Uma vez que as pessoas se comprometem com algo, elas tendem a agir de forma consistente com esse compromisso.',
    techniques: [
      'Pequenos compromissos levam a grandes ações',
      'Use a técnica do "pé na porta"',
      'Obtenha confirmações públicas',
      'Crie rituais de engajamento',
    ],
  },
  {
    id: 3,
    name: 'PROVA SOCIAL',
    icon: '👥',
    color: 'purple',
    description: 'As pessoas olham para o comportamento dos outros para determinar seu próprio comportamento, especialmente em situações incertas.',
    techniques: [
      'Mostre números e estatísticas',
      'Use depoimentos e cases',
      'Exiba selos de confiança',
      'Destaque tendências populares',
    ],
  },
  {
    id: 4,
    name: 'AUTORIDADE',
    icon: '♔',
    color: 'yellow',
    description: 'As pessoas tendem a obedecer a figuras de autoridade, buscando orientação de especialistas e líderes.',
    techniques: [
      'Demonstr expertise e credibilidade',
      'Use títulos e certificações',
      'Cite fontes confiáveis',
      'Vista-se adequadamente',
    ],
  },
  {
    id: 5,
    name: 'GOSTO',
    icon: '♥',
    color: 'green',
    description: 'As pessoas são mais propensas a dizer "sim" a quem conhecem e gostam. Afinidade gera influência.',
    techniques: [
      'Encontre pontos em comum',
      'Dê elogios sinceros',
      'Crie conexões emocionais',
      'Use humor apropriadamente',
    ],
  },
  {
    id: 6,
    name: 'ESCASSEZ',
    icon: '◆',
    color: 'cyan',
    description: 'As oportunidades parecem mais valiosas quando sua disponibilidade é limitada. A escassez cria urgência.',
    techniques: [
      'Crie deadlines reais',
      'Limite a quantidade disponível',
      'Destaque exclusividade',
      'Use contagem regressiva',
    ],
  },
];

const CialdiniSection = () => {
  const [selectedPrinciple, setSelectedPrinciple] = useState<Principle | null>(null);

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#00ff41]/50 px-4 py-2 mb-4 bg-[#00ff41]/5">
            <span className="text-[#00ff41] font-mono text-sm">MÓDULO_01: INFLUÊNCIA</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ff41] neon-glow mb-4">
            OS 6 PRINCÍPIOS DE CIALDINI
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Armas de influência científicamente comprovadas para persuadir e convencer qualquer pessoa.
          </p>
        </div>

        {/* Principles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {principles.map((principle) => (
            <div 
              key={principle.id}
              onClick={() => setSelectedPrinciple(principle)}
              className="cursor-pointer"
            >
              <HolographicCard
                title={principle.name}
                icon={principle.icon}
                glowColor={principle.color}
              >
                <p>{principle.description}</p>
                <div className="mt-4 text-xs text-[#00ff41]/50">
                  CLIQUE PARA VER TÉCNICAS →
                </div>
              </HolographicCard>
            </div>
          ))}
        </div>

        {/* Selected Principle Detail */}
        {selectedPrinciple && (
          <TerminalWindow 
            title={`principle@cialdini:~/${selectedPrinciple.name.toLowerCase()}`}
            className="max-w-3xl mx-auto"
          >
            <div className="space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <span className={`text-3xl ${
                  selectedPrinciple.color === 'green' ? 'text-[#00ff41]' :
                  selectedPrinciple.color === 'cyan' ? 'text-[#00ffff]' :
                  selectedPrinciple.color === 'purple' ? 'text-[#ff00ff]' :
                  'text-[#ffff00]'
                }`}>
                  {selectedPrinciple.icon}
                </span>
                <h3 className="text-xl font-bold text-[#00ff41]">
                  {selectedPrinciple.name}
                </h3>
              </div>

              <div className="text-[#00ff41]/80 mb-4">
                <TypewriterText text={selectedPrinciple.description} delay={20} />
              </div>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#00ffff] font-bold mb-3">:: TÉCNICAS_APLICÁVEIS ::</h4>
                <ul className="space-y-2">
                  {selectedPrinciple.techniques.map((technique, index) => (
                    <li 
                      key={index}
                      className="flex items-center gap-3 text-[#00ff41]/70"
                    >
                      <span className="text-[#00ff41]">▸</span>
                      <span>{technique}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex justify-end mt-4">
                <button 
                  onClick={() => setSelectedPrinciple(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [FECHAR]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}

        {/* Quote */}
        <div className="mt-16 text-center">
          <blockquote className="text-xl md:text-2xl text-[#00ffff] font-mono italic">
            "A influência é a habilidade de fazer as pessoas dizerem 'sim' 
            <br className="hidden md:block" />
            antes mesmo de saberem por quê."
          </blockquote>
          <cite className="block mt-4 text-[#00ff41]/60 font-mono">
            — Dr. Robert Cialdini
          </cite>
        </div>
      </div>
    </section>
  );
};

export default CialdiniSection;
