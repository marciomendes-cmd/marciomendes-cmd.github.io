import { useState } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import TypewriterText from '../components/TypewriterText';

interface Principle {
  id: number;
  title: string;
  description: string;
  action: string;
  icon: string;
}

const principles: Principle[] = [
  {
    id: 1,
    title: 'NÃO CRITIQUE, CONDENE OU RECLAME',
    description: 'A crítica gera defesa. As pessoas não mudam quando se sentem atacadas.',
    action: 'Substitua críticas por feedback construtivo focado em soluções.',
    icon: '✕',
  },
  {
    id: 2,
    title: 'DÊ ELOGIOS SINCEROS E GENUÍNOS',
    description: 'Todos anseiam por reconhecimento. Elogios sinceros criam conexão instantânea.',
    action: 'Observe qualidades específicas e elogie com detalhes autênticos.',
    icon: '★',
  },
  {
    id: 3,
    title: 'DESPERTE DESEJOS VIVIDOS',
    description: 'As pessoas agem por motivos próprios. Mostre como seu pedido beneficia ELAS.',
    action: 'Frame suas propostas em termos do que o outro ganha.',
    icon: '◈',
  },
  {
    id: 4,
    title: 'TORNE-SE GENUINAMENTE INTERESSADO',
    description: 'O interesse genuíno é raro e valioso. As pessoas notam quando você realmente se importa.',
    action: 'Faça perguntas abertas e ouça ativamente sem interromper.',
    icon: '◉',
  },
  {
    id: 5,
    title: 'SORRIA DE FORMA AUTÊNTICA',
    description: 'O sorriso é uma mensagem universal de boa vontade. Transmite confiança e calor.',
    action: 'Pratique sorrisos genuínos que alcancem seus olhos.',
    icon: '☺',
  },
  {
    id: 6,
    title: 'LEMBRE-SE DOS NOMES',
    description: 'O nome é o som mais doce para qualquer pessoa. Memorizar nomes cria conexão.',
    action: 'Repita o nome na conversa, associe a características.',
    icon: '✎',
  },
  {
    id: 7,
    title: 'INCENTIVE OS OUTROS A FALAREM',
    description: 'As pessoas preferem falar a ouvir. Seja um ouvidor excepcional.',
    action: 'Faça perguntas abertas, use silêncios estratégicos.',
    icon: '☰',
  },
  {
    id: 8,
    title: 'FALE SOBRE O QUE INTERESSA A ELES',
    description: 'O interesse mútuo é a base de toda relação duradoura.',
    action: 'Pesquise interesses da pessoa antes de interações importantes.',
    icon: '⚡',
  },
];

const CarnegieSection = () => {
  const [selectedPrinciple, setSelectedPrinciple] = useState<Principle | null>(null);
  const [readPrinciples, setReadPrinciples] = useState<number[]>([]);

  const markAsRead = (id: number) => {
    if (!readPrinciples.includes(id)) {
      setReadPrinciples([...readPrinciples, id]);
    }
  };

  return (
    <section className="py-20 px-4 relative bg-gradient-to-b from-transparent via-[#ffff00]/5 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#ffff00]/50 px-4 py-2 mb-4 bg-[#ffff00]/5">
            <span className="text-[#ffff00] font-mono text-sm">MÓDULO_04: RELACIONAMENTOS</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#ffff00] mb-4"
              style={{ textShadow: '0 0 20px rgba(255,255,0,0.5)' }}>
            DALE CARNEGIE
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            "Como Fazer Amigos e Influenciar Pessoas" — Os princípios atemporais 
            para construir relacionamentos extraordinários.
          </p>
        </div>

        {/* Progress */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="flex justify-between text-sm text-[#00ff41]/60 mb-2 font-mono">
            <span>PROGRESSO_DE_LEITURA</span>
            <span>{readPrinciples.length}/{principles.length}</span>
          </div>
          <div className="h-4 bg-[#00ff41]/10 border border-[#00ff41]/30 rounded overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-[#ffff00] to-[#00ff41] transition-all duration-500"
              style={{ width: `${(readPrinciples.length / principles.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Principles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {principles.map((principle) => (
            <div
              key={principle.id}
              onClick={() => {
                setSelectedPrinciple(principle);
                markAsRead(principle.id);
              }}
              className={`p-4 border rounded-lg cursor-pointer transition-all duration-300 ${
                readPrinciples.includes(principle.id)
                  ? 'border-[#00ff41] bg-[#00ff41]/10'
                  : 'border-[#ffff00]/30 bg-[#ffff00]/5 hover:border-[#ffff00]'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl text-[#ffff00]">{principle.icon}</span>
                <span className="text-xs text-[#00ff41]/50 font-mono">
                  {String(principle.id).padStart(2, '0')}
                </span>
              </div>
              <h3 className="text-sm font-bold text-[#00ff41] mb-2 leading-tight">
                {principle.title}
              </h3>
              <p className="text-xs text-[#00ff41]/60 line-clamp-2">
                {principle.description}
              </p>
              {readPrinciples.includes(principle.id) && (
                <div className="mt-3 flex items-center gap-1 text-xs text-[#00ff41]">
                  <span>✓</span>
                  <span>LIDO</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Selected Principle */}
        {selectedPrinciple && (
          <TerminalWindow
            title={`carnegie@principle:~/${String(selectedPrinciple.id).padStart(2, '0')}`}
            className="max-w-3xl mx-auto"
          >
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <span className="text-4xl text-[#ffff00]">{selectedPrinciple.icon}</span>
                <div>
                  <div className="text-xs text-[#00ff41]/50 mb-1">
                    PRINCÍPIO {String(selectedPrinciple.id).padStart(2, '0')}
                  </div>
                  <h3 className="text-xl font-bold text-[#ffff00]">
                    {selectedPrinciple.title}
                  </h3>
                </div>
              </div>

              <div className="text-[#00ff41]/80">
                <TypewriterText 
                  text={selectedPrinciple.description}
                  delay={20}
                  showCursor={false}
                />
              </div>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#00ffff] font-bold mb-3 flex items-center gap-2">
                  <span>▶</span>
                  <span>AÇÃO_PRÁTICA</span>
                </h4>
                <p className="text-[#00ff41]/70 bg-[#00ff41]/5 p-4 rounded border-l-2 border-[#00ff41]">
                  {selectedPrinciple.action}
                </p>
              </div>

              <div className="flex justify-between items-center pt-4">
                <div className="text-xs text-[#00ff41]/50">
                  {readPrinciples.includes(selectedPrinciple.id) 
                    ? '✓ PRINCÍPIO ASSIMILADO' 
                    : '○ CLICAR PARA MARCAR COMO LIDO'}
                </div>
                <button
                  onClick={() => setSelectedPrinciple(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [FECHAR]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}

        {/* Carnegie Quote */}
        <div className="mt-16 text-center">
          <div className="inline-block p-8 border border-[#ffff00]/30 bg-[#ffff00]/5 rounded-lg max-w-3xl">
            <blockquote className="text-xl md:text-2xl text-[#ffff00] font-mono italic mb-4">
              "Você pode fazer mais amigos em dois meses se se interessar 
              genuinamente por outras pessoas do que em dois anos tentando 
              fazer outras pessoas se interessarem por você."
            </blockquote>
            <cite className="text-[#00ff41]/60 font-mono not-italic">
              — Dale Carnegie
            </cite>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CarnegieSection;
