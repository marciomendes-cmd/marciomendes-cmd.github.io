import { useState } from 'react';
import TerminalWindow from '../components/TerminalWindow';

interface Experience {
  id: number;
  title: string;
  company: string;
  location: string;
  period: string;
  type: 'current' | 'previous';
  responsibilities: string[];
  achievements: string[];
  technologies: string[];
}

const experiences: Experience[] = [
  {
    id: 1,
    title: 'Vulnerability Management Analyst | Security Operations',
    company: 'ISH Tecnologia',
    location: 'São Paulo, Brazil',
    period: '12/2023 – 12/2025',
    type: 'current',
    responsibilities: [
      'Hands-on enterprise vulnerability management using Qualys VMDR and Tenable.io platforms',
      'Performed risk-based triage combining CVSS scores, asset criticality and threat intelligence',
      'Supported remediation tracking through ticket-based workflows and technical reporting',
      'Automated vulnerability triage and reporting processes to reduce MTTR (Mean Time To Remediate)',
      'Provided technical guidance through comprehensive documentation, runbooks and standardized remediation workflows',
      'Translated complex CVE and CVSS data into clear, actionable remediation steps for engineering teams',
      'Managed asynchronous, ticket-based workflows ensuring SLA compliance and operational continuity',
    ],
    achievements: [
      'Reduced MTTR for critical vulnerabilities by 60% through automation and improved workflows',
      'Implemented risk-based prioritization that increased team efficiency by 40%',
      'Developed standardized runbooks that improved consistency across remediation efforts',
    ],
    technologies: ['Qualys VMDR', 'Tenable.io', 'Tenable.sc', 'CVSS', 'CVE Analysis', 'MTTR Reduction', 'Ticketing Systems', 'Risk-Based Prioritization'],
  },
  {
    id: 2,
    title: 'Lead System Administrator',
    company: 'Metamorfose 9',
    location: 'São Paulo, SP',
    period: '08/2018 – 12/2023',
    type: 'previous',
    responsibilities: [
      'Defense in Depth: Implemented and maintained perimeter security controls configuring firewalls and routers with robust VPNs to shield against unauthorized access',
      'Cloud Operations (AWS): Managed backup and business continuity infrastructure in AWS, ensuring the integrity and restoration of critical databases (MySQL/Firebird)',
      'Monitoring & Response: Implemented proactive web threat monitoring (WAF/Wordfence) and vulnerability remediation based on the MITRE ATT&CK framework',
      'Infrastructure Administration: Optimized Windows Server environments (AD, DNS, DHCP), implementing GPO policies and strict access control (IAM) to mitigate insider threats',
      'Compliance: Adapted internal processes and controls to align with ISO 27001 guidelines',
      'Led security initiatives that protected critical business assets and ensured operational continuity',
    ],
    achievements: [
      'Successfully implemented ISO 27001-aligned security controls',
      'Reduced security incidents by 45% through proactive monitoring and threat detection',
      'Managed AWS infrastructure ensuring 99.9% uptime for critical business systems',
    ],
    technologies: ['AWS', 'Windows Server', 'Active Directory', 'DNS', 'DHCP', 'GPO', 'IAM', 'WAF', 'Wordfence', 'MITRE ATT&CK', 'ISO 27001', 'VPN', 'Firewalls'],
  },
  {
    id: 3,
    title: 'Network Administrator',
    company: 'Linkfort Telecom',
    location: 'São Paulo, SP',
    period: '01/2017 – 06/2017',
    type: 'previous',
    responsibilities: [
      'High-complexity incident management and critical infrastructure support',
      'Ensured SLAs and operational continuity for telecommunications infrastructure',
      'Managed network security and performance optimization',
      'Provided technical support for critical network infrastructure',
    ],
    achievements: [
      'Maintained 99.5% SLA compliance throughout tenure',
      'Resolved critical incidents with minimal downtime impact',
    ],
    technologies: ['Network Security', 'Incident Management', 'SLA Compliance', 'Infrastructure Support'],
  },
  {
    id: 4,
    title: 'Network Administrator',
    company: 'Morada da Praia Condominium',
    location: 'São Paulo, SP',
    period: '09/2007 – 06/2009',
    type: 'previous',
    responsibilities: [
      'Complete network infrastructure management for residential condominium',
      'Pioneering implementation of vulnerability analysis with Nessus in the organization',
      'Designed and maintained network architecture ensuring security and performance',
      'Implemented security policies and access controls',
    ],
    achievements: [
      'First to implement vulnerability scanning with Nessus in the organization',
      'Established foundational security practices still in use today',
    ],
    technologies: ['Nessus', 'Network Infrastructure', 'Vulnerability Analysis', 'Security Policies'],
  },
];

const ExperienceSection = () => {
  const [selectedExp, setSelectedExp] = useState<Experience | null>(null);
  const [hoveredExp, setHoveredExp] = useState<number | null>(null);

  return (
    <section id="experience" className="py-20 px-4 relative bg-gradient-to-b from-transparent via-[#00ff41]/5 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#00ffff]/50 px-4 py-2 mb-4 bg-[#00ffff]/5">
            <span className="text-[#00ffff] font-mono text-sm">MODULE_02: CAREER_LOG</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ffff] neon-glow-cyan mb-4">
            PROFESSIONAL EXPERIENCE
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            7+ years securing enterprise environments. From vulnerability management 
            to cloud security operations. Click on any position for detailed responsibilities.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-[#00ff41]/30 md:-translate-x-px"></div>

          {/* Experience Items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div 
                key={exp.id}
                className={`relative flex flex-col md:flex-row gap-8 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline Dot */}
                <div className={`absolute left-4 md:left-1/2 w-4 h-4 -translate-x-1/2 rounded-full border-2 z-10
                              ${exp.type === 'current' ? 'bg-[#00ff41] border-[#00ff41] animate-pulse' : 'bg-[#0d0208] border-[#00ff41]'}`}>
                </div>

                {/* Content */}
                <div className={`ml-12 md:ml-0 md:w-1/2 ${index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'}`}>
                  <div 
                    className={`p-6 border rounded-lg cursor-pointer transition-all duration-300 ${
                      hoveredExp === exp.id
                        ? 'border-[#00ff41] bg-[#00ff41]/10 shadow-[0_0_20px_rgba(0,255,65,0.3)]'
                        : 'border-[#00ff41]/30 bg-[#00ff41]/5'
                    }`}
                    onMouseEnter={() => setHoveredExp(exp.id)}
                    onMouseLeave={() => setHoveredExp(null)}
                    onClick={() => setSelectedExp(exp)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-xs px-2 py-1 rounded ${
                        exp.type === 'current' 
                          ? 'bg-[#00ff41]/20 text-[#00ff41]' 
                          : 'bg-[#00ff41]/10 text-[#00ff41]/60'
                      }`}>
                        {exp.type === 'current' ? '● CURRENT' : '○ PREVIOUS'}
                      </span>
                      <span className="text-[#00ff41]/50 text-sm font-mono">{exp.period}</span>
                    </div>

                    <h3 className="text-lg font-bold text-[#00ff41] mb-1">{exp.title}</h3>
                    <p className="text-[#00ffff] text-sm mb-3">{exp.company}</p>
                    <p className="text-[#00ff41]/50 text-xs mb-4">📍 {exp.location}</p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {exp.technologies.slice(0, 4).map((tech) => (
                        <span 
                          key={tech}
                          className="px-2 py-1 text-xs border border-[#00ff41]/30 text-[#00ff41]/60"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    <div className="text-[#00ff41]/50 text-xs">
                      CLICK FOR FULL DETAILS →
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Experience Detail */}
        {selectedExp && (
          <TerminalWindow
            title={`experience@detail:~/${selectedExp.company.toLowerCase().replace(/\s+/g, '_')}`}
            className="max-w-4xl mx-auto mt-12"
          >
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-bold text-[#00ff41]">{selectedExp.title}</h3>
                  <p className="text-[#00ffff]">{selectedExp.company}</p>
                  <p className="text-[#00ff41]/50 text-sm">📍 {selectedExp.location} | {selectedExp.period}</p>
                </div>
                <span className={`text-xs px-3 py-1 rounded ${
                  selectedExp.type === 'current' 
                    ? 'bg-[#00ff41]/20 text-[#00ff41]' 
                    : 'bg-[#00ff41]/10 text-[#00ff41]/60'
                }`}>
                  {selectedExp.type === 'current' ? 'CURRENT' : 'PREVIOUS'}
                </span>
              </div>

              {/* Key Responsibilities */}
              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#ffff00] font-bold mb-4 flex items-center gap-2">
                  <span>▶</span>
                  <span>KEY RESPONSIBILITIES</span>
                </h4>
                <ul className="space-y-3">
                  {selectedExp.responsibilities.map((resp, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className="text-[#00ff41] mt-1">▸</span>
                      <span className="text-[#00ff41]/80">{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Key Achievements */}
              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#00ffff] font-bold mb-4 flex items-center gap-2">
                  <span>★</span>
                  <span>KEY ACHIEVEMENTS</span>
                </h4>
                <ul className="space-y-3">
                  {selectedExp.achievements.map((achievement, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className="text-[#00ffff] mt-1">✓</span>
                      <span className="text-[#00ff41]/80">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Technologies */}
              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#ff00ff] font-bold mb-3">:: TECHNOLOGIES & TOOLS ::</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedExp.technologies.map((tech) => (
                    <span 
                      key={tech}
                      className="px-3 py-1 text-sm border border-[#ff00ff]/30 text-[#ff00ff]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Close Button */}
              <div className="flex justify-end">
                <button
                  onClick={() => setSelectedExp(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [CLOSE]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}
      </div>
    </section>
  );
};

export default ExperienceSection;
