import { useState, useEffect } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import MatrixProgress from '../components/MatrixProgress';
import HolographicCard from '../components/HolographicCard';

interface SkillCategory {
  name: string;
  icon: string;
  color: 'green' | 'cyan' | 'purple' | 'yellow';
  skills: { name: string; level: number }[];
}

const skillCategories: SkillCategory[] = [
  {
    name: 'VULNERABILITY MANAGEMENT',
    icon: '🔍',
    color: 'green',
    skills: [
      { name: 'Qualys VMDR', level: 95 },
      { name: 'Tenable.io/sc', level: 90 },
      { name: 'Risk-Based Prioritization', level: 92 },
      { name: 'CVE/CVSS Analysis', level: 88 },
      { name: 'Patch Management', level: 85 },
    ],
  },
  {
    name: 'OFFENSIVE SECURITY',
    icon: '⚔️',
    color: 'cyan',
    skills: [
      { name: 'Web/Infra Pentesting', level: 82 },
      { name: 'MITRE ATT&CK Framework', level: 88 },
      { name: 'Burp Suite', level: 78 },
      { name: 'Purple Team Approach', level: 85 },
      { name: 'API Penetration Testing', level: 75 },
    ],
  },
  {
    name: 'RISK & COMPLIANCE',
    icon: '🛡️',
    color: 'purple',
    skills: [
      { name: 'FAIR™ / CRQ', level: 80 },
      { name: 'NIST Framework', level: 85 },
      { name: 'ISO 27001', level: 88 },
      { name: 'PCI-DSS', level: 75 },
      { name: 'Threat-Informed Defense', level: 82 },
    ],
  },
  {
    name: 'INFRASTRUCTURE',
    icon: '⚙️',
    color: 'yellow',
    skills: [
      { name: 'AWS Cloud Security', level: 80 },
      { name: 'Windows Server / AD', level: 85 },
      { name: 'Network Security', level: 88 },
      { name: 'Firewall/VPN Config', level: 82 },
      { name: 'SIEM Tools', level: 78 },
    ],
  },
];

const tools = [
  'Qualys Cloud Platform', 'Tenable.io', 'Nessus', 'Burp Suite',
  'Wordfence', 'AWS', 'MITRE ATT&CK', 'SIEM', 'Nmap', 'Wireshark'
];

const SkillsSection = () => {
  const [activeCategory, setActiveCategory] = useState<string>('VULNERABILITY MANAGEMENT');
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const activeSkills = skillCategories.find(c => c.name === activeCategory);

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#00ff41]/50 px-4 py-2 mb-4 bg-[#00ff41]/5">
            <span className="text-[#00ff41] font-mono text-sm">MODULE_01: SKILL_MATRIX</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#00ff41] neon-glow mb-4">
            TECHNICAL ARSENAL
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Comprehensive skill set in vulnerability management, offensive security, 
            and enterprise risk assessment.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {skillCategories.map((cat) => (
            <button
              key={cat.name}
              onClick={() => setActiveCategory(cat.name)}
              className={`px-6 py-3 font-mono text-sm border transition-all duration-300 ${
                activeCategory === cat.name
                  ? 'bg-[#00ff41]/20 border-[#00ff41] text-[#00ff41]'
                  : 'border-[#00ff41]/30 text-[#00ff41]/60 hover:border-[#00ff41] hover:text-[#00ff41]'
              }`}
            >
              <span className="mr-2">{cat.icon}</span>
              {cat.name}
            </button>
          ))}
        </div>

        {/* Skills Display */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Progress Bars */}
          <TerminalWindow title={`skills@matrix:~/${activeCategory.toLowerCase().replace(/\s+/g, '_')}`}>
            {showContent && activeSkills && (
              <div className="space-y-6">
                {activeSkills.skills.map((skill, index) => (
                  <MatrixProgress
                    key={skill.name}
                    label={skill.name}
                    targetValue={skill.level}
                    duration={1500 + index * 200}
                  />
                ))}
              </div>
            )}
          </TerminalWindow>

          {/* Skill Cards */}
          <div className="grid grid-cols-1 gap-4">
            {activeSkills && (
              <HolographicCard
                title={activeSkills.name}
                icon={activeSkills.icon}
                glowColor={activeSkills.color}
              >
                <div className="space-y-4">
                  <p className="text-[#00ff41]/80">
                    Expert-level proficiency with hands-on experience in enterprise environments.
                    Proven track record of reducing MTTR and implementing risk-based prioritization.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {activeSkills.skills.slice(0, 3).map((skill) => (
                      <span 
                        key={skill.name}
                        className="px-3 py-1 text-xs border border-[#00ff41]/30 text-[#00ff41]/70"
                      >
                        {skill.name}
                      </span>
                    ))}
                  </div>
                </div>
              </HolographicCard>
            )}

            {/* Tools Grid */}
            <div className="p-6 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg">
              <h3 className="text-[#00ffff] font-bold mb-4 flex items-center gap-2">
                <span>🛠️</span>
                <span>TOOLS & PLATFORMS</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {tools.map((tool) => (
                  <span 
                    key={tool}
                    className="px-3 py-1 text-xs border border-[#00ffff]/30 text-[#00ffff]/70 
                             hover:border-[#00ffff] hover:text-[#00ffff] transition-all cursor-default"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Languages */}
        <div className="flex flex-wrap justify-center gap-8">
          <div className="text-center p-6 border border-[#ffff00]/30 bg-[#ffff00]/5 rounded-lg">
            <div className="text-3xl mb-2">🇧🇷</div>
            <div className="text-[#ffff00] font-bold">PORTUGUESE</div>
            <div className="text-[#00ff41]/60 text-sm">Native</div>
          </div>
          <div className="text-center p-6 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg">
            <div className="text-3xl mb-2">🇺🇸</div>
            <div className="text-[#00ffff] font-bold">ENGLISH</div>
            <div className="text-[#00ff41]/60 text-sm">Professional (Written & Technical)</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
