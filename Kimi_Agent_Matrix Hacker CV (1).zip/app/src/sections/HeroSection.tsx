import { useState, useEffect } from 'react';
import TypewriterText from '../components/TypewriterText';
import GlitchText from '../components/GlitchText';

const HeroSection = () => {
  const [showContent, setShowContent] = useState(false);
  const [bootSequence, setBootSequence] = useState(0);

  const bootLines = [
    '>>> INITIALIZING SECURITY PROTOCOLS...',
    '>>> LOADING QUALYS VMDR MODULES...',
    '>>> CONNECTING TO TENABLE.IO...',
    '>>> VULNERABILITY DATABASE SYNCED.',
    '>>> ACCESS GRANTED. WELCOME, OPERATOR.',
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 2500);

    const bootInterval = setInterval(() => {
      setBootSequence(prev => {
        if (prev < bootLines.length - 1) {
          return prev + 1;
        }
        clearInterval(bootInterval);
        return prev;
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      clearInterval(bootInterval);
    };
  }, []);

  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative px-4 py-20">
      {/* ASCII Art Banner */}
      <div className="text-center mb-8">
        <pre className="text-[#00ff41] text-[10px] md:text-xs lg:text-sm font-mono leading-none hidden md:block">
{`
╔══════════════════════════════════════════════════════════════════════════════╗
║  ███╗   ███╗ █████╗ ██████╗  ██████╗██╗ ██████╗      ███╗   ███╗███████╗    ║
║  ████╗ ████║██╔══██╗██╔══██╗██╔════╝██║██╔═══██╗     ████╗ ████║██╔════╝    ║
║  ██╔████╔██║███████║██████╔╝██║     ██║██║   ██║     ██╔████╔██║█████╗      ║
║  ██║╚██╔╝██║██╔══██║██╔══██╗██║     ██║██║   ██║     ██║╚██╔╝██║██╔══╝      ║
║  ██║ ╚═╝ ██║██║  ██║██║  ██║╚██████╗██║╚██████╔╝     ██║ ╚═╝ ██║███████╗    ║
║  ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝ ╚═════╝      ╚═╝     ╚═╝╚══════╝    ║
╚══════════════════════════════════════════════════════════════════════════════╝
`}
        </pre>
        
        {/* Mobile Banner */}
        <div className="md:hidden text-[#00ff41] font-mono text-3xl font-bold neon-glow">
          <GlitchText text="MARCIO MENDES" glitchInterval={2000} />
        </div>
      </div>

      {/* Boot Sequence */}
      <div className="w-full max-w-3xl mb-8 font-mono text-sm">
        {bootLines.slice(0, bootSequence + 1).map((line, index) => (
          <div 
            key={index} 
            className={`${index === bootSequence ? 'text-[#00ff41]' : 'text-[#00ff41]/50'}`}
          >
            {index === bootSequence && index < bootLines.length - 1 ? (
              <TypewriterText text={line} delay={20} showCursor={false} />
            ) : (
              line
            )}
          </div>
        ))}
      </div>

      {/* Main Content */}
      {showContent && (
        <div className="text-center animate-fade-in">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-[#00ff41] neon-glow">
              <GlitchText text="VULNERABILITY MANAGEMENT" glitchInterval={4000} />
            </span>
          </h1>
          
          <h2 className="text-xl md:text-2xl text-[#00ffff] mb-4 font-mono">
            <TypewriterText 
              text="⚡ Security Operations Analyst ⚡" 
              delay={40}
            />
          </h2>

          <p className="text-[#00ff41]/70 text-lg md:text-xl max-w-2xl mx-auto mb-6 font-mono">
            Specialized in <span className="text-[#ffff00]">Qualys VMDR</span> & 
            <span className="text-[#ff00ff]"> Tenable.io</span>. 
            Risk-based prioritization, CVE/CVSS analysis, and threat-informed defense.
          </p>

          {/* Contact Info */}
          <div className="flex flex-wrap justify-center gap-4 mb-8 text-sm font-mono">
            <span className="px-4 py-2 border border-[#00ff41]/30 text-[#00ff41]/70">
              📍 São Paulo, Brazil (Remote Ready)
            </span>
            <span className="px-4 py-2 border border-[#00ff41]/30 text-[#00ff41]/70">
              📧 marciomendes.ads@gmail.com
            </span>
            <a 
              href="https://wa.me/551398140337"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 border border-[#25d366]/30 text-[#25d366] hover:bg-[#25d366]/10 transition-all"
            >
              💬 WhatsApp
            </a>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <a 
              href="https://www.linkedin.com/in/this-marcio-qualys-vmdr/"
              target="_blank"
              rel="noopener noreferrer"
              className="matrix-btn text-lg px-8 py-4"
            >
              <span className="mr-2">▶</span> LINKEDIN PROFILE
            </a>
            <button 
              onClick={() => document.getElementById('articles')?.scrollIntoView({ behavior: 'smooth' })}
              className="matrix-btn text-lg px-8 py-4 border-[#ff00ff] text-[#ff00ff] hover:shadow-[#ff00ff]"
            >
              <span className="mr-2">◈</span> VIEW ARTICLES
            </button>
          </div>

          {/* Download CV Button */}
          <div className="flex justify-center">
            <a 
              href="/cv-marcio-mendes.pdf"
              download="Marcio_Mendes_Vulnerability_Management_Analyst.pdf"
              className="group relative px-8 py-4 border-2 border-[#ffff00] text-[#ffff00] font-mono font-bold
                       hover:bg-[#ffff00]/10 transition-all duration-300 flex items-center gap-3"
            >
              <span className="text-2xl group-hover:animate-bounce">📄</span>
              <span>DOWNLOAD CV (PDF)</span>
              <span className="text-sm opacity-60">[2.4 MB]</span>
              <span className="absolute inset-0 border-2 border-[#ffff00] opacity-0 group-hover:opacity-50 
                             group-hover:scale-110 transition-all duration-300"></span>
            </a>
          </div>

          {/* Stats */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              { value: '7+', label: 'YEARS EXP', color: '#00ff41' },
              { value: '10K+', label: 'ASSETS SCANNED', color: '#00ffff' },
              { value: '15+', label: 'CERTIFICATIONS', color: '#ff00ff' },
              { value: '5+', label: 'PUBLICATIONS', color: '#ffff00' },
            ].map((stat, index) => (
              <div 
                key={index} 
                className="text-center p-4 border border-[#00ff41]/30 rounded bg-[#00ff41]/5"
              >
                <div 
                  className="text-3xl md:text-4xl font-bold font-mono"
                  style={{ color: stat.color, textShadow: `0 0 10px ${stat.color}` }}
                >
                  {stat.value}
                </div>
                <div className="text-xs text-[#00ff41]/60 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="text-[#00ff41]/50 text-sm font-mono">
          <span className="block text-center mb-2">[SCROLL]</span>
          <span className="block text-center text-2xl">▼</span>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
