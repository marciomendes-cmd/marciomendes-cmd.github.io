import { useState } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import HolographicCard from '../components/HolographicCard';

interface Education {
  id: number;
  degree: string;
  institution: string;
  location: string;
  period: string;
  description: string;
  highlights: string[];
}

const educations: Education[] = [
  {
    id: 1,
    degree: 'Postgraduate Certificate in Information Security',
    institution: 'ITA - Instituto Tecnológico de Aeronáutica',
    location: 'São Paulo, SP',
    period: '03/2008 – 12/2011',
    description: 'Top-tier Engineering & Aeronautics Institute in Brazil. Advanced studies in information security, risk management, and cybersecurity frameworks.',
    highlights: [
      'Advanced Information Security',
      'Risk Management & Governance',
      'Cryptography & Network Security',
      'Security Architecture',
    ],
  },
  {
    id: 2,
    degree: 'Computer Network Management',
    institution: 'UNIP - Universidade Paulista',
    location: 'Santos, SP',
    period: '01/2004 – 12/2007',
    description: 'Comprehensive degree in computer network administration, infrastructure management, and systems security.',
    highlights: [
      'Network Infrastructure',
      'Systems Administration',
      'Database Management',
      'Security Fundamentals',
    ],
  },
];

const EducationSection = () => {
  const [selectedEdu, setSelectedEdu] = useState<Education | null>(null);

  return (
    <section className="py-20 px-4 relative bg-gradient-to-b from-transparent via-[#00ffff]/5 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#ffff00]/50 px-4 py-2 mb-4 bg-[#ffff00]/5">
            <span className="text-[#ffff00] font-mono text-sm">MODULE_04: ACADEMIC_RECORD</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#ffff00] mb-4"
              style={{ textShadow: '0 0 20px rgba(255,255,0,0.5)' }}>
            EDUCATION
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Academic foundation in Information Security from Brazil's top-tier 
            engineering institute combined with hands-on network management expertise.
          </p>
        </div>

        {/* Education Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {educations.map((edu) => (
            <div
              key={edu.id}
              onClick={() => setSelectedEdu(edu)}
              className="cursor-pointer"
            >
              <HolographicCard
                title={edu.degree}
                icon="🎓"
                glowColor="yellow"
              >
                <div className="space-y-4">
                  <div>
                    <p className="text-[#00ffff] font-bold">{edu.institution}</p>
                    <p className="text-[#00ff41]/50 text-sm">📍 {edu.location}</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-[#ffff00]">📅</span>
                    <span className="text-[#00ff41]/70 text-sm">{edu.period}</span>
                  </div>

                  <p className="text-[#00ff41]/60 text-sm line-clamp-2">
                    {edu.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {edu.highlights.slice(0, 3).map((highlight, index) => (
                      <span 
                        key={index}
                        className="px-2 py-1 text-xs border border-[#ffff00]/30 text-[#ffff00]/70"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>

                  <div className="text-[#00ff41]/50 text-xs mt-2">
                    CLICK FOR DETAILS →
                  </div>
                </div>
              </HolographicCard>
            </div>
          ))}
        </div>

        {/* ITA Highlight */}
        <div className="p-8 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg max-w-3xl mx-auto">
          <div className="flex items-start gap-4">
            <div className="text-4xl">🏛️</div>
            <div>
              <h3 className="text-xl font-bold text-[#00ffff] mb-2">
                ITA - Instituto Tecnológico de Aeronáutica
              </h3>
              <p className="text-[#00ff41]/70 mb-4">
                Brazil's premier engineering and aeronautics institute, equivalent to MIT in the US. 
                The postgraduate program in Information Security provided advanced training in 
                cybersecurity frameworks, risk management, and security architecture.
              </p>
              <div className="flex items-center gap-4 text-sm">
                <span className="px-3 py-1 bg-[#00ff41]/20 text-[#00ff41]">
                  TOP-TIER INSTITUTE
                </span>
                <span className="px-3 py-1 bg-[#00ffff]/20 text-[#00ffff]">
                  POSTGRADUATE LEVEL
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Education Detail */}
        {selectedEdu && (
          <TerminalWindow
            title={`edu@record:~/${selectedEdu.institution.toLowerCase().replace(/\s+/g, '_').substring(0, 20)}`}
            className="max-w-3xl mx-auto mt-12"
          >
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-[#ffff00]">{selectedEdu.degree}</h3>
                <p className="text-[#00ffff]">{selectedEdu.institution}</p>
                <p className="text-[#00ff41]/50 text-sm">📍 {selectedEdu.location}</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[#ffff00]">📅</span>
                <span className="text-[#00ff41]/70">{selectedEdu.period}</span>
              </div>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#00ffff] font-bold mb-3">:: PROGRAM_OVERVIEW ::</h4>
                <p className="text-[#00ff41]/70">{selectedEdu.description}</p>
              </div>

              <div className="border-t border-[#00ff41]/30 pt-4">
                <h4 className="text-[#ffff00] font-bold mb-3">:: KEY_HIGHLIGHTS ::</h4>
                <ul className="space-y-2">
                  {selectedEdu.highlights.map((highlight, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <span className="text-[#00ff41]">▸</span>
                      <span className="text-[#00ff41]/70">{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setSelectedEdu(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [CLOSE]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}
      </div>
    </section>
  );
};

export default EducationSection;
