import { useState } from 'react';
import TerminalWindow from '../components/TerminalWindow';
import { 
  articles, 
  getFeaturedArticles, 
  getAllTags, 
  typeLabels, 
  typeColors,
  type Article 
} from '../config/articles';

const ArticlesSection = () => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [filter, setFilter] = useState<string>('ALL');
  const [tagFilter, setTagFilter] = useState<string>('ALL');

  const allTags = getAllTags();
  const featuredArticles = getFeaturedArticles();

  // Filter articles
  let filteredArticles = articles;
  if (filter !== 'ALL') {
    filteredArticles = filteredArticles.filter(a => a.type === filter);
  }
  if (tagFilter !== 'ALL') {
    filteredArticles = filteredArticles.filter(a => a.tags.includes(tagFilter));
  }

  const filters = ['ALL', 'peerspot', 'casestudy', 'bugbounty', 'writeup'];

  return (
    <section className="py-20 px-4 relative bg-gradient-to-b from-transparent via-[#ff00ff]/5 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block border border-[#ff00ff]/50 px-4 py-2 mb-4 bg-[#ff00ff]/5">
            <span className="text-[#ff00ff] font-mono text-sm">MODULE_05: WRITEUPS & CASE STUDIES</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#ff00ff] neon-glow-purple mb-4">
            ARTICLES & REVIEWS
          </h2>
          <p className="text-[#00ff41]/70 text-lg max-w-2xl mx-auto font-mono">
            Proving expertise through published reviews, case studies, and security research. 
            Demonstrating written communication skills essential for async remote work.
          </p>
        </div>

        {/* Featured Articles */}
        <div className="mb-16">
          <h3 className="text-xl font-bold text-[#ffff00] mb-6 flex items-center gap-2">
            <span>★</span>
            <span>FEATURED PUBLICATIONS</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredArticles.slice(0, 2).map((article) => (
              <div
                key={article.id}
                onClick={() => setSelectedArticle(article)}
                className="p-6 border border-[#00ff41]/30 bg-[#00ff41]/5 rounded-lg cursor-pointer
                         hover:border-[#00ff41] hover:bg-[#00ff41]/10 transition-all duration-300
                         hover:shadow-[0_0_20px_rgba(0,255,65,0.3)]"
              >
                <div className="flex items-center justify-between mb-3">
                  <span 
                    className="px-3 py-1 text-xs font-mono border"
                    style={{ 
                      color: typeColors[article.type],
                      borderColor: typeColors[article.type]
                    }}
                  >
                    {typeLabels[article.type]}
                  </span>
                  <span className="text-[#00ff41]/50 text-sm">{article.date}</span>
                </div>
                <h4 className="text-lg font-bold text-[#00ff41] mb-2">{article.title}</h4>
                <p className="text-[#00ff41]/60 text-sm mb-4">{article.excerpt}</p>
                <div className="flex flex-wrap gap-2">
                  {article.tags.slice(0, 3).map((tag) => (
                    <span key={tag} className="px-2 py-1 text-xs border border-[#00ff41]/30 text-[#00ff41]/60">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 font-mono text-xs border transition-all duration-300 ${
                filter === f
                  ? 'bg-[#ff00ff]/20 border-[#ff00ff] text-[#ff00ff]'
                  : 'border-[#00ff41]/30 text-[#00ff41]/60 hover:border-[#00ff41] hover:text-[#00ff41]'
              }`}
            >
              {f === 'ALL' ? 'ALL TYPES' : typeLabels[f as Article['type']]}
            </button>
          ))}
        </div>

        {/* Tag Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          <button
            onClick={() => setTagFilter('ALL')}
            className={`px-3 py-1 text-xs border transition-all ${
              tagFilter === 'ALL'
                ? 'bg-[#00ffff]/20 border-[#00ffff] text-[#00ffff]'
                : 'border-[#00ff41]/20 text-[#00ff41]/40 hover:border-[#00ff41]/50'
            }`}
          >
            ALL TAGS
          </button>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setTagFilter(tag)}
              className={`px-3 py-1 text-xs border transition-all ${
                tagFilter === tag
                  ? 'bg-[#00ffff]/20 border-[#00ffff] text-[#00ffff]'
                  : 'border-[#00ff41]/20 text-[#00ff41]/40 hover:border-[#00ff41]/50'
              }`}
            >
              #{tag}
            </button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredArticles.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="p-5 border border-[#00ff41]/20 bg-[#00ff41]/5 rounded-lg cursor-pointer
                       hover:border-[#00ff41]/50 hover:bg-[#00ff41]/10 transition-all duration-300"
            >
              <div className="flex items-center justify-between mb-2">
                <span 
                  className="text-xs font-mono"
                  style={{ color: typeColors[article.type] }}
                >
                  {typeLabels[article.type]}
                </span>
                <span className="text-[#00ff41]/40 text-xs">{article.date}</span>
              </div>
              <h4 className="text-sm font-bold text-[#00ff41] mb-2 line-clamp-2">{article.title}</h4>
              <p className="text-[#00ff41]/50 text-xs line-clamp-2 mb-3">{article.excerpt}</p>
              <div className="flex flex-wrap gap-1">
                {article.tags.slice(0, 2).map((tag) => (
                  <span key={tag} className="px-2 py-0.5 text-xs border border-[#00ff41]/20 text-[#00ff41]/40">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Selected Article Detail */}
        {selectedArticle && (
          <TerminalWindow
            title={`article@read:~/${selectedArticle.id}`}
            className="max-w-4xl mx-auto"
          >
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span 
                      className="px-3 py-1 text-xs font-mono border"
                      style={{ 
                        color: typeColors[selectedArticle.type],
                        borderColor: typeColors[selectedArticle.type]
                      }}
                    >
                      {typeLabels[selectedArticle.type]}
                    </span>
                    <span className="text-[#00ff41]/50 text-sm">{selectedArticle.date}</span>
                  </div>
                  <h3 className="text-xl font-bold text-[#00ff41]">{selectedArticle.title}</h3>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {selectedArticle.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 text-xs border border-[#00ff41]/30 text-[#00ff41]/70">
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Content */}
              <div className="border-t border-[#00ff41]/30 pt-4 space-y-4">
                {selectedArticle.content.map((paragraph, index) => (
                  <p key={index} className="text-[#00ff41]/80 leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* External Link */}
              {selectedArticle.link && (
                <div className="border-t border-[#00ff41]/30 pt-4">
                  <a
                    href={selectedArticle.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 border border-[#00ffff] text-[#00ffff] 
                             hover:bg-[#00ffff]/10 transition-all"
                  >
                    <span>🔗</span>
                    <span>READ FULL REVIEW ON PEERSPOT</span>
                    <span>→</span>
                  </a>
                </div>
              )}

              {/* Close Button */}
              <div className="flex justify-end">
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="text-[#00ff41]/50 hover:text-[#00ff41] text-sm"
                >
                  [CLOSE]
                </button>
              </div>
            </div>
          </TerminalWindow>
        )}

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center p-4 border border-[#00ff41]/30 bg-[#00ff41]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#00ff41]">{articles.length}</div>
            <div className="text-xs text-[#00ff41]/60">TOTAL PUBLICATIONS</div>
          </div>
          <div className="text-center p-4 border border-[#00ffff]/30 bg-[#00ffff]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#00ffff]">{articles.filter(a => a.type === 'peerspot').length}</div>
            <div className="text-xs text-[#00ff41]/60">PEERSPOT REVIEWS</div>
          </div>
          <div className="text-center p-4 border border-[#ff00ff]/30 bg-[#ff00ff]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#ff00ff]">{articles.filter(a => a.type === 'casestudy').length}</div>
            <div className="text-xs text-[#00ff41]/60">CASE STUDIES</div>
          </div>
          <div className="text-center p-4 border border-[#ffff00]/30 bg-[#ffff00]/5 rounded-lg">
            <div className="text-3xl font-bold text-[#ffff00]">{allTags.length}</div>
            <div className="text-xs text-[#00ff41]/60">TOPICS COVERED</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ArticlesSection;
