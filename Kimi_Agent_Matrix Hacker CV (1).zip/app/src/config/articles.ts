// ============================================
// ARTICLES CONFIGURATION FILE
// ============================================
// Add, remove or edit articles easily here
// Each article is an object with the following properties:
// - id: unique identifier (string)
// - title: article title (string)
// - type: 'peerspot' | 'casestudy' | 'bugbounty' | 'writeup'
// - excerpt: short description (string)
// - content: full article content (array of paragraphs)
// - link: external link (optional string)
// - date: publication date (string)
// - tags: array of tags (string[])
// - featured: boolean - show in featured section
// ============================================

export interface Article {
  id: string;
  title: string;
  type: 'peerspot' | 'casestudy' | 'bugbounty' | 'writeup';
  excerpt: string;
  content: string[];
  link?: string;
  date: string;
  tags: string[];
  featured: boolean;
}

export const articles: Article[] = [
  // ============================================
  // PEERSPOT REVIEW 1 - Asset Intelligence
  // ============================================
  {
    id: 'peerspot-asset-intelligence',
    title: 'Asset Intelligence Transformed Risk Visibility',
    type: 'peerspot',
    excerpt: 'How Qualys Cybersecurity Asset Management (CSAM) supports lifecycle control and reporting for enterprise environments.',
    content: [
      'Asset intelligence has transformed risk visibility and supports lifecycle control and reporting. In enterprise environments, knowing what assets you have is the foundation of any security program.',
      'Qualys CSAM provides comprehensive asset discovery and inventory capabilities that go beyond traditional CMDB approaches. The platform automatically discovers and classifies assets across cloud, on-premises, and hybrid environments.',
      'The real power comes from the correlation between asset data and vulnerability information. By understanding the business context of each asset, security teams can prioritize remediation efforts based on actual risk rather than just CVSS scores.',
      'Lifecycle control features enable automated workflows for asset onboarding, monitoring, and decommissioning. This ensures that security coverage is maintained throughout the entire asset lifecycle.',
      'Reporting capabilities provide executives with clear visibility into the organization\'s security posture, while technical teams get the detailed information they need for day-to-day operations.',
    ],
    link: 'https://www.peerspot.com/products/qualys-cybersecurity-asset-management-reviews?review_id=10425071',
    date: '2024',
    tags: ['Qualys', 'CSAM', 'Asset Management', 'Risk Visibility'],
    featured: true,
  },

  // ============================================
  // PEERSPOT REVIEW 2 - Patch Management
  // ============================================
  {
    id: 'peerspot-patch-management',
    title: 'Unified Risk-Based Patching Reduces Vulnerabilities',
    type: 'peerspot',
    excerpt: 'How Qualys Patch Management automates thousands of server updates with risk-based prioritization.',
    content: [
      'Unified risk-based patching has reduced vulnerabilities and automates thousands of server updates. Traditional patch management approaches often struggle with scale and prioritization.',
      'Qualys Patch Management integrates seamlessly with the VMDR platform, enabling security teams to move from vulnerability identification to remediation in a single workflow.',
      'The risk-based approach means that patches are prioritized based on the actual threat landscape, asset criticality, and exposure. This ensures that the most critical vulnerabilities are addressed first.',
      'Automation capabilities allow for scheduled patching windows, maintenance mode handling, and rollback procedures. This reduces the manual effort required and minimizes the risk of service disruptions.',
      'With thousands of servers under management, the ability to automate patch deployment while maintaining risk-based prioritization has been transformative for operational efficiency.',
    ],
    link: 'https://www.peerspot.com/products/qualys-patch-management-reviews?review_id=10950357',
    date: '2024',
    tags: ['Qualys', 'Patch Management', 'Automation', 'Risk-Based'],
    featured: true,
  },

  // ============================================
  // CASE STUDY - Beyond CVSS
  // ============================================
  {
    id: 'casestudy-beyond-cvss',
    title: 'How I Prioritize Beyond CVSS Using Threat Intelligence',
    type: 'casestudy',
    excerpt: 'A practical approach to vulnerability prioritization that combines CVSS, threat intelligence, asset criticality, and business context.',
    content: [
      'CVSS scores provide a standardized way to measure vulnerability severity, but they don\'t tell the whole story. In my experience managing enterprise vulnerability programs, relying solely on CVSS leads to inefficient resource allocation and missed critical risks.',
      'My approach combines four key factors: CVSS Base Score (20%), Threat Intelligence (30%), Asset Criticality (30%), and Exposure/Context (20%). This weighted model ensures that vulnerabilities actively exploited in the wild receive immediate attention, even if their CVSS score is moderate.',
      'Threat intelligence integration is crucial. By monitoring CISA KEV, exploit databases, and threat actor campaigns, I can identify which vulnerabilities pose immediate risks. A CVSS 7.0 vulnerability with active exploitation becomes Priority 1, while a CVSS 9.0 with no known exploits might be Priority 2.',
      'Asset criticality adds business context. A vulnerability on a public-facing web server hosting customer data is more critical than the same vulnerability on an internal test server. This context is often missing from pure CVSS-based approaches.',
      'The results speak for themselves: MTTR for critical vulnerabilities dropped by 60%, and the security team\'s efficiency improved significantly by focusing on what actually matters to the business.',
    ],
    date: '2024',
    tags: ['CVSS', 'Threat Intelligence', 'Risk-Based Prioritization', 'Vulnerability Management'],
    featured: true,
  },

  // ============================================
  // BUG BOUNTY REPORT
  // ============================================
  {
    id: 'bugbounty-api-vulnerability',
    title: 'API Authorization Bypass: A Bug Bounty Report',
    type: 'bugbounty',
    excerpt: 'How I discovered and reported a critical API vulnerability that allowed unauthorized access to sensitive customer data.',
    content: [
      'During a bug bounty program for a fintech company, I discovered a critical authorization bypass in their REST API that allowed authenticated users to access other customers\' financial data by simply modifying a numeric ID parameter in the request.',
      'The vulnerability existed in the /api/v1/transactions/{id} endpoint. While the API properly validated authentication tokens, it failed to verify that the requested transaction ID belonged to the authenticated user. This is a classic Insecure Direct Object Reference (IDOR) vulnerability.',
      'Using Burp Suite, I systematically tested various endpoints and found that the same pattern existed across multiple API resources: accounts, statements, and personal information. The impact was severe - any authenticated user could access any other user\'s data.',
      'I documented the vulnerability with clear reproduction steps, provided a video demonstration, and suggested remediation: implement proper authorization checks that verify resource ownership before returning data. The company patched the issue within 48 hours.',
      'This finding was rewarded with a $3,500 bounty and highlighted the importance of thorough authorization testing in API security assessments.',
    ],
    date: '2023',
    tags: ['Bug Bounty', 'API Security', 'IDOR', 'Authorization'],
    featured: true,
  },

  // ============================================
  // WRITEUP - MTTR Reduction
  // ============================================
  {
    id: 'writeup-mttr-reduction',
    title: 'Reducing MTTR: Automation in Vulnerability Management',
    type: 'writeup',
    excerpt: 'How automated workflows and smart ticketing reduced Mean Time To Remediate by 60% in an enterprise environment.',
    content: [
      'Mean Time To Remediate (MTTR) is a critical metric for any vulnerability management program. In my previous role, we faced challenges with manual processes that created delays between vulnerability identification and remediation.',
      'I implemented an automated workflow that integrates Qualys VMDR with our ticketing system. When a new critical vulnerability is detected, the system automatically creates a ticket with all relevant context: CVE details, affected assets, exploit availability, and remediation guidance.',
      'The automation includes intelligent routing based on asset ownership and vulnerability type. Network vulnerabilities go to the network team, application issues to developers, and infrastructure problems to the systems team. This eliminates the manual triage bottleneck.',
      'Dashboards and reporting provide visibility into the remediation pipeline, allowing managers to track progress and identify blockers. Weekly automated reports keep stakeholders informed without manual effort.',
      'The result: MTTR for critical vulnerabilities dropped from 15 days to 6 days - a 60% improvement. The security team could focus on strategic work instead of manual ticket creation and follow-up.',
    ],
    date: '2024',
    tags: ['MTTR', 'Automation', 'Vulnerability Management', 'Workflow'],
    featured: false,
  },
];

// ============================================
// HELPER FUNCTIONS
// ============================================

// Get all featured articles
export const getFeaturedArticles = () => articles.filter(a => a.featured);

// Get articles by type
export const getArticlesByType = (type: Article['type']) => 
  articles.filter(a => a.type === type);

// Get articles by tag
export const getArticlesByTag = (tag: string) => 
  articles.filter(a => a.tags.includes(tag));

// Get article by ID
export const getArticleById = (id: string) => 
  articles.find(a => a.id === id);

// Get all unique tags
export const getAllTags = () => 
  [...new Set(articles.flatMap(a => a.tags))];

// Type labels for display
export const typeLabels: Record<Article['type'], string> = {
  peerspot: 'PEERSPOT REVIEW',
  casestudy: 'CASE STUDY',
  bugbounty: 'BUG BOUNTY',
  writeup: 'WRITE-UP',
};

// Type colors for display
export const typeColors: Record<Article['type'], string> = {
  peerspot: '#00ff41',
  casestudy: '#00ffff',
  bugbounty: '#ff00ff',
  writeup: '#ffff00',
};
